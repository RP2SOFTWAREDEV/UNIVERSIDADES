﻿namespace seminario2
{
    partial class Principal
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            facturasToolStripMenuItem = new ToolStripMenuItem();
            crearFacturaToolStripMenuItem = new ToolStripMenuItem();
            consultarFacturaToolStripMenuItem = new ToolStripMenuItem();
            eliminarFacturaToolStripMenuItem = new ToolStripMenuItem();
            proveedoresToolStripMenuItem = new ToolStripMenuItem();
            cátalogoProveedorToolStripMenuItem = new ToolStripMenuItem();
            añadirProductoToolStripMenuItem = new ToolStripMenuItem();
            modificarProductoToolStripMenuItem = new ToolStripMenuItem();
            eliminarProductoToolStripMenuItem = new ToolStripMenuItem();
            consultarCatálogoToolStripMenuItem = new ToolStripMenuItem();
            datosProveedorToolStripMenuItem = new ToolStripMenuItem();
            cargarProveedorToolStripMenuItem1 = new ToolStripMenuItem();
            modificarProveedorToolStripMenuItem1 = new ToolStripMenuItem();
            eliminarProveedorToolStripMenuItem1 = new ToolStripMenuItem();
            productosFinalToolStripMenuItem = new ToolStripMenuItem();
            categoríasToolStripMenuItem = new ToolStripMenuItem();
            crearCategoríaToolStripMenuItem1 = new ToolStripMenuItem();
            eliminarCategoríaToolStripMenuItem = new ToolStripMenuItem();
            modificarCategoríaToolStripMenuItem1 = new ToolStripMenuItem();
            subcategoríasToolStripMenuItem1 = new ToolStripMenuItem();
            crearSubcategoríaToolStripMenuItem1 = new ToolStripMenuItem();
            eliminarSubcategoríaToolStripMenuItem1 = new ToolStripMenuItem();
            modificarSubcategoríaToolStripMenuItem1 = new ToolStripMenuItem();
            productoToolStripMenuItem = new ToolStripMenuItem();
            cargarProductoToolStripMenuItem2 = new ToolStripMenuItem();
            eliminarProductoToolStripMenuItem2 = new ToolStripMenuItem();
            modificarProductoToolStripMenuItem2 = new ToolStripMenuItem();
            habilitarProductoToolStripMenuItem2 = new ToolStripMenuItem();
            consultarProductoToolStripMenuItem2 = new ToolStripMenuItem();
            reportesToolStripMenuItem = new ToolStripMenuItem();
            gananciasToolStripMenuItem = new ToolStripMenuItem();
            gastosToolStripMenuItem = new ToolStripMenuItem();
            utilidadToolStripMenuItem = new ToolStripMenuItem();
            estadísticasToolStripMenuItem = new ToolStripMenuItem();
            mesDeMayorGananciaToolStripMenuItem = new ToolStripMenuItem();
            mesDeMenorGananciaToolStripMenuItem = new ToolStripMenuItem();
            productoMasVendidoToolStripMenuItem = new ToolStripMenuItem();
            productoMenosVendidoToolStripMenuItem = new ToolStripMenuItem();
            cantidadVecesProductoVendidoToolStripMenuItem = new ToolStripMenuItem();
            panelContenedor = new Panel();
            consultarProveedorToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { facturasToolStripMenuItem, proveedoresToolStripMenuItem, productosFinalToolStripMenuItem, reportesToolStripMenuItem, estadísticasToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(833, 24);
            menuStrip1.TabIndex = 6;
            menuStrip1.Text = "menuStrip1";
            menuStrip1.ItemClicked += menuStrip1_ItemClicked;
            // 
            // facturasToolStripMenuItem
            // 
            facturasToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { crearFacturaToolStripMenuItem, consultarFacturaToolStripMenuItem, eliminarFacturaToolStripMenuItem });
            facturasToolStripMenuItem.Name = "facturasToolStripMenuItem";
            facturasToolStripMenuItem.Size = new Size(53, 20);
            facturasToolStripMenuItem.Text = "Ventas";
            // 
            // crearFacturaToolStripMenuItem
            // 
            crearFacturaToolStripMenuItem.Name = "crearFacturaToolStripMenuItem";
            crearFacturaToolStripMenuItem.Size = new Size(157, 22);
            crearFacturaToolStripMenuItem.Text = "Nueva venta";
            crearFacturaToolStripMenuItem.Click += crearFacturaToolStripMenuItem_Click;
            // 
            // consultarFacturaToolStripMenuItem
            // 
            consultarFacturaToolStripMenuItem.Name = "consultarFacturaToolStripMenuItem";
            consultarFacturaToolStripMenuItem.Size = new Size(157, 22);
            consultarFacturaToolStripMenuItem.Text = "Consultar venta";
            consultarFacturaToolStripMenuItem.Click += consultarFacturaToolStripMenuItem_Click;
            // 
            // eliminarFacturaToolStripMenuItem
            // 
            eliminarFacturaToolStripMenuItem.Name = "eliminarFacturaToolStripMenuItem";
            eliminarFacturaToolStripMenuItem.Size = new Size(157, 22);
            eliminarFacturaToolStripMenuItem.Text = "Eliminar venta";
            eliminarFacturaToolStripMenuItem.Click += eliminarFacturaToolStripMenuItem_Click;
            // 
            // proveedoresToolStripMenuItem
            // 
            proveedoresToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { cátalogoProveedorToolStripMenuItem, datosProveedorToolStripMenuItem });
            proveedoresToolStripMenuItem.Name = "proveedoresToolStripMenuItem";
            proveedoresToolStripMenuItem.Size = new Size(84, 20);
            proveedoresToolStripMenuItem.Text = "Proveedores";
            // 
            // cátalogoProveedorToolStripMenuItem
            // 
            cátalogoProveedorToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { añadirProductoToolStripMenuItem, modificarProductoToolStripMenuItem, eliminarProductoToolStripMenuItem, consultarCatálogoToolStripMenuItem });
            cátalogoProveedorToolStripMenuItem.Name = "cátalogoProveedorToolStripMenuItem";
            cátalogoProveedorToolStripMenuItem.Size = new Size(180, 22);
            cátalogoProveedorToolStripMenuItem.Text = "Cátalogo Proveedor";
            // 
            // añadirProductoToolStripMenuItem
            // 
            añadirProductoToolStripMenuItem.Name = "añadirProductoToolStripMenuItem";
            añadirProductoToolStripMenuItem.Size = new Size(177, 22);
            añadirProductoToolStripMenuItem.Text = "Añadir Producto";
            añadirProductoToolStripMenuItem.Click += añadirProductoToolStripMenuItem_Click;
            // 
            // modificarProductoToolStripMenuItem
            // 
            modificarProductoToolStripMenuItem.Name = "modificarProductoToolStripMenuItem";
            modificarProductoToolStripMenuItem.Size = new Size(177, 22);
            modificarProductoToolStripMenuItem.Text = "Modificar Producto";
            // 
            // eliminarProductoToolStripMenuItem
            // 
            eliminarProductoToolStripMenuItem.Name = "eliminarProductoToolStripMenuItem";
            eliminarProductoToolStripMenuItem.Size = new Size(177, 22);
            eliminarProductoToolStripMenuItem.Text = "Eliminar Producto";
            // 
            // consultarCatálogoToolStripMenuItem
            // 
            consultarCatálogoToolStripMenuItem.Name = "consultarCatálogoToolStripMenuItem";
            consultarCatálogoToolStripMenuItem.Size = new Size(177, 22);
            consultarCatálogoToolStripMenuItem.Text = "Consultar Catálogo";
            // 
            // datosProveedorToolStripMenuItem
            // 
            datosProveedorToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { cargarProveedorToolStripMenuItem1, modificarProveedorToolStripMenuItem1, eliminarProveedorToolStripMenuItem1, consultarProveedorToolStripMenuItem });
            datosProveedorToolStripMenuItem.Name = "datosProveedorToolStripMenuItem";
            datosProveedorToolStripMenuItem.Size = new Size(180, 22);
            datosProveedorToolStripMenuItem.Text = "Datos Proveedor";
            // 
            // cargarProveedorToolStripMenuItem1
            // 
            cargarProveedorToolStripMenuItem1.Name = "cargarProveedorToolStripMenuItem1";
            cargarProveedorToolStripMenuItem1.Size = new Size(182, 22);
            cargarProveedorToolStripMenuItem1.Text = "Cargar Proveedor";
            // 
            // modificarProveedorToolStripMenuItem1
            // 
            modificarProveedorToolStripMenuItem1.Name = "modificarProveedorToolStripMenuItem1";
            modificarProveedorToolStripMenuItem1.Size = new Size(182, 22);
            modificarProveedorToolStripMenuItem1.Text = "Modificar Proveedor";
            // 
            // eliminarProveedorToolStripMenuItem1
            // 
            eliminarProveedorToolStripMenuItem1.Name = "eliminarProveedorToolStripMenuItem1";
            eliminarProveedorToolStripMenuItem1.Size = new Size(182, 22);
            eliminarProveedorToolStripMenuItem1.Text = "Eliminar Proveedor";
            // 
            // productosFinalToolStripMenuItem
            // 
            productosFinalToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { categoríasToolStripMenuItem, subcategoríasToolStripMenuItem1, productoToolStripMenuItem });
            productosFinalToolStripMenuItem.Name = "productosFinalToolStripMenuItem";
            productosFinalToolStripMenuItem.Size = new Size(76, 20);
            productosFinalToolStripMenuItem.Text = "Productos ";
            // 
            // categoríasToolStripMenuItem
            // 
            categoríasToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { crearCategoríaToolStripMenuItem1, eliminarCategoríaToolStripMenuItem, modificarCategoríaToolStripMenuItem1 });
            categoríasToolStripMenuItem.Name = "categoríasToolStripMenuItem";
            categoríasToolStripMenuItem.Size = new Size(148, 22);
            categoríasToolStripMenuItem.Text = "Categorías";
            // 
            // crearCategoríaToolStripMenuItem1
            // 
            crearCategoríaToolStripMenuItem1.Name = "crearCategoríaToolStripMenuItem1";
            crearCategoríaToolStripMenuItem1.Size = new Size(177, 22);
            crearCategoríaToolStripMenuItem1.Text = "Crear categoría";
            crearCategoríaToolStripMenuItem1.Click += crearCategoríaToolStripMenuItem1_Click;
            // 
            // eliminarCategoríaToolStripMenuItem
            // 
            eliminarCategoríaToolStripMenuItem.Name = "eliminarCategoríaToolStripMenuItem";
            eliminarCategoríaToolStripMenuItem.Size = new Size(177, 22);
            eliminarCategoríaToolStripMenuItem.Text = "Eliminar categoría";
            eliminarCategoríaToolStripMenuItem.Click += eliminarCategoríaToolStripMenuItem_Click;
            // 
            // modificarCategoríaToolStripMenuItem1
            // 
            modificarCategoríaToolStripMenuItem1.Name = "modificarCategoríaToolStripMenuItem1";
            modificarCategoríaToolStripMenuItem1.Size = new Size(177, 22);
            modificarCategoríaToolStripMenuItem1.Text = "Modificar categoría";
            modificarCategoríaToolStripMenuItem1.Click += modificarCategoríaToolStripMenuItem1_Click;
            // 
            // subcategoríasToolStripMenuItem1
            // 
            subcategoríasToolStripMenuItem1.DropDownItems.AddRange(new ToolStripItem[] { crearSubcategoríaToolStripMenuItem1, eliminarSubcategoríaToolStripMenuItem1, modificarSubcategoríaToolStripMenuItem1 });
            subcategoríasToolStripMenuItem1.Name = "subcategoríasToolStripMenuItem1";
            subcategoríasToolStripMenuItem1.Size = new Size(148, 22);
            subcategoríasToolStripMenuItem1.Text = "Subcategorías";
            // 
            // crearSubcategoríaToolStripMenuItem1
            // 
            crearSubcategoríaToolStripMenuItem1.Name = "crearSubcategoríaToolStripMenuItem1";
            crearSubcategoríaToolStripMenuItem1.Size = new Size(196, 22);
            crearSubcategoríaToolStripMenuItem1.Text = "Crear subcategoría";
            crearSubcategoríaToolStripMenuItem1.Click += crearSubcategoríaToolStripMenuItem1_Click;
            // 
            // eliminarSubcategoríaToolStripMenuItem1
            // 
            eliminarSubcategoríaToolStripMenuItem1.Name = "eliminarSubcategoríaToolStripMenuItem1";
            eliminarSubcategoríaToolStripMenuItem1.Size = new Size(196, 22);
            eliminarSubcategoríaToolStripMenuItem1.Text = "Eliminar subcategoría";
            eliminarSubcategoríaToolStripMenuItem1.Click += eliminarSubcategoríaToolStripMenuItem1_Click;
            // 
            // modificarSubcategoríaToolStripMenuItem1
            // 
            modificarSubcategoríaToolStripMenuItem1.Name = "modificarSubcategoríaToolStripMenuItem1";
            modificarSubcategoríaToolStripMenuItem1.Size = new Size(196, 22);
            modificarSubcategoríaToolStripMenuItem1.Text = "Modificar subcategoría";
            modificarSubcategoríaToolStripMenuItem1.Click += modificarSubcategoríaToolStripMenuItem1_Click;
            // 
            // productoToolStripMenuItem
            // 
            productoToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { cargarProductoToolStripMenuItem2, eliminarProductoToolStripMenuItem2, modificarProductoToolStripMenuItem2, habilitarProductoToolStripMenuItem2, consultarProductoToolStripMenuItem2 });
            productoToolStripMenuItem.Name = "productoToolStripMenuItem";
            productoToolStripMenuItem.Size = new Size(148, 22);
            productoToolStripMenuItem.Text = "Productos";
            // 
            // cargarProductoToolStripMenuItem2
            // 
            cargarProductoToolStripMenuItem2.Name = "cargarProductoToolStripMenuItem2";
            cargarProductoToolStripMenuItem2.Size = new Size(177, 22);
            cargarProductoToolStripMenuItem2.Text = "Cargar Producto";
            cargarProductoToolStripMenuItem2.Click += cargarProductoToolStripMenuItem2_Click;
            // 
            // eliminarProductoToolStripMenuItem2
            // 
            eliminarProductoToolStripMenuItem2.Name = "eliminarProductoToolStripMenuItem2";
            eliminarProductoToolStripMenuItem2.Size = new Size(177, 22);
            eliminarProductoToolStripMenuItem2.Text = "Eliminar Producto";
            eliminarProductoToolStripMenuItem2.Click += eliminarProductoToolStripMenuItem2_Click;
            // 
            // modificarProductoToolStripMenuItem2
            // 
            modificarProductoToolStripMenuItem2.Name = "modificarProductoToolStripMenuItem2";
            modificarProductoToolStripMenuItem2.Size = new Size(177, 22);
            modificarProductoToolStripMenuItem2.Text = "Modificar Producto";
            modificarProductoToolStripMenuItem2.Click += modificarProductoToolStripMenuItem2_Click;
            // 
            // habilitarProductoToolStripMenuItem2
            // 
            habilitarProductoToolStripMenuItem2.Name = "habilitarProductoToolStripMenuItem2";
            habilitarProductoToolStripMenuItem2.Size = new Size(177, 22);
            habilitarProductoToolStripMenuItem2.Text = "Habilitar Producto";
            habilitarProductoToolStripMenuItem2.Click += habilitarProductoToolStripMenuItem2_Click;
            // 
            // consultarProductoToolStripMenuItem2
            // 
            consultarProductoToolStripMenuItem2.Name = "consultarProductoToolStripMenuItem2";
            consultarProductoToolStripMenuItem2.Size = new Size(177, 22);
            consultarProductoToolStripMenuItem2.Text = "Consultar Producto";
            consultarProductoToolStripMenuItem2.Click += consultarProductoToolStripMenuItem2_Click;
            // 
            // reportesToolStripMenuItem
            // 
            reportesToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { gananciasToolStripMenuItem, gastosToolStripMenuItem, utilidadToolStripMenuItem });
            reportesToolStripMenuItem.Name = "reportesToolStripMenuItem";
            reportesToolStripMenuItem.Size = new Size(65, 20);
            reportesToolStripMenuItem.Text = "Reportes";
            // 
            // gananciasToolStripMenuItem
            // 
            gananciasToolStripMenuItem.Name = "gananciasToolStripMenuItem";
            gananciasToolStripMenuItem.Size = new Size(128, 22);
            gananciasToolStripMenuItem.Text = "Ganancias";
            // 
            // gastosToolStripMenuItem
            // 
            gastosToolStripMenuItem.Name = "gastosToolStripMenuItem";
            gastosToolStripMenuItem.Size = new Size(128, 22);
            gastosToolStripMenuItem.Text = "Gastos";
            // 
            // utilidadToolStripMenuItem
            // 
            utilidadToolStripMenuItem.Name = "utilidadToolStripMenuItem";
            utilidadToolStripMenuItem.Size = new Size(128, 22);
            utilidadToolStripMenuItem.Text = "Utilidad";
            // 
            // estadísticasToolStripMenuItem
            // 
            estadísticasToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { mesDeMayorGananciaToolStripMenuItem, mesDeMenorGananciaToolStripMenuItem, productoMasVendidoToolStripMenuItem, productoMenosVendidoToolStripMenuItem, cantidadVecesProductoVendidoToolStripMenuItem });
            estadísticasToolStripMenuItem.Name = "estadísticasToolStripMenuItem";
            estadísticasToolStripMenuItem.Size = new Size(79, 20);
            estadísticasToolStripMenuItem.Text = "Estadísticas";
            // 
            // mesDeMayorGananciaToolStripMenuItem
            // 
            mesDeMayorGananciaToolStripMenuItem.Name = "mesDeMayorGananciaToolStripMenuItem";
            mesDeMayorGananciaToolStripMenuItem.Size = new Size(208, 22);
            mesDeMayorGananciaToolStripMenuItem.Text = "Mes de mayor ganancia";
            // 
            // mesDeMenorGananciaToolStripMenuItem
            // 
            mesDeMenorGananciaToolStripMenuItem.Name = "mesDeMenorGananciaToolStripMenuItem";
            mesDeMenorGananciaToolStripMenuItem.Size = new Size(208, 22);
            mesDeMenorGananciaToolStripMenuItem.Text = "Mes de menor ganancia";
            // 
            // productoMasVendidoToolStripMenuItem
            // 
            productoMasVendidoToolStripMenuItem.Name = "productoMasVendidoToolStripMenuItem";
            productoMasVendidoToolStripMenuItem.Size = new Size(208, 22);
            productoMasVendidoToolStripMenuItem.Text = "Producto mas vendido";
            // 
            // productoMenosVendidoToolStripMenuItem
            // 
            productoMenosVendidoToolStripMenuItem.Name = "productoMenosVendidoToolStripMenuItem";
            productoMenosVendidoToolStripMenuItem.Size = new Size(208, 22);
            productoMenosVendidoToolStripMenuItem.Text = "Producto menos vendido";
            // 
            // cantidadVecesProductoVendidoToolStripMenuItem
            // 
            cantidadVecesProductoVendidoToolStripMenuItem.Name = "cantidadVecesProductoVendidoToolStripMenuItem";
            cantidadVecesProductoVendidoToolStripMenuItem.Size = new Size(208, 22);
            cantidadVecesProductoVendidoToolStripMenuItem.Text = "Cantidad veces vendido";
            // 
            // panelContenedor
            // 
            panelContenedor.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panelContenedor.Location = new Point(0, 27);
            panelContenedor.Name = "panelContenedor";
            panelContenedor.Size = new Size(833, 423);
            panelContenedor.TabIndex = 7;
            panelContenedor.Paint += panelContenedor_Paint;
            // 
            // consultarProveedorToolStripMenuItem
            // 
            consultarProveedorToolStripMenuItem.Name = "consultarProveedorToolStripMenuItem";
            consultarProveedorToolStripMenuItem.Size = new Size(182, 22);
            consultarProveedorToolStripMenuItem.Text = "Consultar Proveedor";
            consultarProveedorToolStripMenuItem.Click += consultarProveedorToolStripMenuItem_Click;
            // 
            // Principal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(833, 450);
            Controls.Add(panelContenedor);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Principal";
            Text = "Menu Principal";
            WindowState = FormWindowState.Maximized;
            Load += Principal_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private MenuStrip menuStrip1;
        private ToolStripMenuItem facturasToolStripMenuItem;
        private ToolStripMenuItem crearFacturaToolStripMenuItem;
        private ToolStripMenuItem consultarFacturaToolStripMenuItem;
        private Panel panelContenedor;
        private ToolStripMenuItem eliminarFacturaToolStripMenuItem;
        private ToolStripMenuItem proveedoresToolStripMenuItem;
        private ToolStripMenuItem productosFinalToolStripMenuItem;
        private ToolStripMenuItem categoríasToolStripMenuItem;
        private ToolStripMenuItem subcategoríasToolStripMenuItem1;
        private ToolStripMenuItem productoToolStripMenuItem;
        private ToolStripMenuItem cargarProductoToolStripMenuItem2;
        private ToolStripMenuItem eliminarProductoToolStripMenuItem2;
        private ToolStripMenuItem modificarProductoToolStripMenuItem2;
        private ToolStripMenuItem habilitarProductoToolStripMenuItem2;
        private ToolStripMenuItem crearCategoríaToolStripMenuItem1;
        private ToolStripMenuItem eliminarCategoríaToolStripMenuItem;
        private ToolStripMenuItem modificarCategoríaToolStripMenuItem1;
        private ToolStripMenuItem crearSubcategoríaToolStripMenuItem1;
        private ToolStripMenuItem eliminarSubcategoríaToolStripMenuItem1;
        private ToolStripMenuItem modificarSubcategoríaToolStripMenuItem1;
        private ToolStripMenuItem consultarProductoToolStripMenuItem2;
        private ToolStripMenuItem reportesToolStripMenuItem;
        private ToolStripMenuItem gananciasToolStripMenuItem;
        private ToolStripMenuItem estadísticasToolStripMenuItem;
        private ToolStripMenuItem gastosToolStripMenuItem;
        private ToolStripMenuItem utilidadToolStripMenuItem;
        private ToolStripMenuItem mesDeMayorGananciaToolStripMenuItem;
        private ToolStripMenuItem mesDeMenorGananciaToolStripMenuItem;
        private ToolStripMenuItem productoMasVendidoToolStripMenuItem;
        private ToolStripMenuItem productoMenosVendidoToolStripMenuItem;
        private ToolStripMenuItem cantidadVecesProductoVendidoToolStripMenuItem;
        private ToolStripMenuItem cátalogoProveedorToolStripMenuItem;
        private ToolStripMenuItem añadirProductoToolStripMenuItem;
        private ToolStripMenuItem modificarProductoToolStripMenuItem;
        private ToolStripMenuItem eliminarProductoToolStripMenuItem;
        private ToolStripMenuItem consultarCatálogoToolStripMenuItem;
        private ToolStripMenuItem datosProveedorToolStripMenuItem;
        private ToolStripMenuItem cargarProveedorToolStripMenuItem1;
        private ToolStripMenuItem modificarProveedorToolStripMenuItem1;
        private ToolStripMenuItem eliminarProveedorToolStripMenuItem1;
        private ToolStripMenuItem consultarProveedorToolStripMenuItem;
    }
}