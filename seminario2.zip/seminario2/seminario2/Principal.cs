using seminario2.Interfases;
using seminario2.Interfases.Categoria;
using seminario2.Interfases.VentanaFacturas;
using seminario2.Interfases.VentanaProducto;
using seminario2.Interfases.VentanaProveedores;
using seminario2.Interfases.VentanaProveedorXProducto;
using seminario2.Interfases.VentanaSubcategoria;
using seminario2.Interfases.VentanaUsuario;

namespace seminario2
{
    public partial class Principal : Form
    {
        public static int idUsuario;
        public Principal(int id_Usuario)
        {
            idUsuario = id_Usuario;
            MessageBox.Show(idUsuario.ToString());
            InitializeComponent();
        }
        public Principal() : this(5)
        {

        }



        private void AbrirFormHija(object formhija)
        {
            if (this.panelContenedor.Controls.Count > 0)
                this.panelContenedor.Controls.RemoveAt(0);
            Form fh = formhija as Form;
            fh.TopLevel = false;
            fh.Dock = DockStyle.Fill;
            fh.StartPosition = FormStartPosition.CenterParent;
            this.panelContenedor.Controls.Add(fh);
            this.panelContenedor.Tag = fh;
            fh.Show();

        }



        private void crearCategor�aToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new vtnCargarCategoria());
        }

        private void borrarCategor�aToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new BorrarCategoria());
        }

        private void modificarCategor�aToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new ModificarCategoria());
        }

        private void crearSubcategor�aToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new CargarSubcategoria());
        }

        private void eliminarSubcategor�aToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new BorrarSubcategoria());
        }

        private void modificarSubcategor�aToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new ModificarSubcategoria());
        }

        private void cargarProductoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new vtnCargarProductos());
        }

        private void eliminarProductoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new BorrarProducto());
        }

        private void modificarProductoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new ModificarProducto());
        }

        private void habilitarProductoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new ActivarProducto());
        }

        private void consultarProductoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new ConsultarProducto());

        }

        private void crearFacturaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new CargarFactura());

        }

        private void consultarFacturaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new ConsultarFacturas());

        }

        private void panelContenedor_Paint(object sender, PaintEventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Principal_Load(object sender, EventArgs e)
        {
            AbrirFormHija(new Comienzo());
        }

        private void eliminarFacturaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new EliminarFactura());
        }

        private void cargarProveedorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new CargarProveedor());
        }

        private void modificarProveedorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new ModificarProveedores());
        }

        private void eliminarProveedorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new EliminarProveedor());
        }

        private void crearCategor�aToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new vtnCargarCategoria());
        }

        private void eliminarCategor�aToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new BorrarCategoria());
        }

        private void modificarCategor�aToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new ModificarCategoria());
        }

        private void crearSubcategor�aToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new CargarSubcategoria());
        }

        private void eliminarSubcategor�aToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new BorrarSubcategoria());
        }

        private void modificarSubcategor�aToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new ModificarSubcategoria());
        }

        private void cargarProductoToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new vtnCargarProductos());
        }

        private void eliminarProductoToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new BorrarProducto());
        }

        private void modificarProductoToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new ModificarProducto());
        }

        private void habilitarProductoToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new ActivarProducto());
        }

        private void consultarProductoToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new ConsultarProducto());
        }

        private void a�adirProductoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new A�adirProveedorxProducto());
        }

        private void consultarProveedorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormHija(new ConsultarProveedor());
        }
    }

}

