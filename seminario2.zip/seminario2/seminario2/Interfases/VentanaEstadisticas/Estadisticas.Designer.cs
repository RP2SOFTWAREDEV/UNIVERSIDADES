﻿namespace seminario2.Interfases.VentanaCategoria
{
    partial class Estadisticas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            Opciones = new GroupBox();
            productoXmes = new RadioButton();
            cincoMenosVendidos = new RadioButton();
            diezMasVendidos = new RadioButton();
            Fechas = new GroupBox();
            label3 = new Label();
            label2 = new Label();
            fechaHasta = new DateTimePicker();
            fechaDesde = new DateTimePicker();
            Producto = new GroupBox();
            txtProducto = new TextBox();
            label5 = new Label();
            btBuscar = new Button();
            txtIdProducto = new TextBox();
            label4 = new Label();
            Opciones.SuspendLayout();
            Fechas.SuspendLayout();
            Producto.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(153, 80);
            label1.Name = "label1";
            label1.Size = new Size(0, 15);
            label1.TabIndex = 0;
            // 
            // Opciones
            // 
            Opciones.Controls.Add(productoXmes);
            Opciones.Controls.Add(cincoMenosVendidos);
            Opciones.Controls.Add(diezMasVendidos);
            Opciones.Location = new Point(12, 68);
            Opciones.Name = "Opciones";
            Opciones.Size = new Size(246, 142);
            Opciones.TabIndex = 1;
            Opciones.TabStop = false;
            Opciones.Text = "Opciones";
            // 
            // productoXmes
            // 
            productoXmes.AutoSize = true;
            productoXmes.Location = new Point(28, 83);
            productoXmes.Name = "productoXmes";
            productoXmes.Size = new Size(156, 19);
            productoXmes.TabIndex = 2;
            productoXmes.TabStop = true;
            productoXmes.Text = "venta de producto x mes";
            productoXmes.UseVisualStyleBackColor = true;
            // 
            // cincoMenosVendidos
            // 
            cincoMenosVendidos.AutoSize = true;
            cincoMenosVendidos.Location = new Point(28, 58);
            cincoMenosVendidos.Name = "cincoMenosVendidos";
            cincoMenosVendidos.Size = new Size(178, 19);
            cincoMenosVendidos.TabIndex = 1;
            cincoMenosVendidos.TabStop = true;
            cincoMenosVendidos.Text = "5 productos menos vendidos";
            cincoMenosVendidos.UseVisualStyleBackColor = true;
            // 
            // diezMasVendidos
            // 
            diezMasVendidos.AutoSize = true;
            diezMasVendidos.Location = new Point(28, 33);
            diezMasVendidos.Name = "diezMasVendidos";
            diezMasVendidos.Size = new Size(170, 19);
            diezMasVendidos.TabIndex = 0;
            diezMasVendidos.TabStop = true;
            diezMasVendidos.Text = "10 productos mas vendidos";
            diezMasVendidos.UseVisualStyleBackColor = true;
            // 
            // Fechas
            // 
            Fechas.Controls.Add(label3);
            Fechas.Controls.Add(label2);
            Fechas.Controls.Add(fechaHasta);
            Fechas.Controls.Add(fechaDesde);
            Fechas.Location = new Point(276, 80);
            Fechas.Name = "Fechas";
            Fechas.Size = new Size(245, 130);
            Fechas.TabIndex = 2;
            Fechas.TabStop = false;
            Fechas.Text = "Fechas";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(21, 72);
            label3.Name = "label3";
            label3.Size = new Size(72, 15);
            label3.TabIndex = 4;
            label3.Text = "Fecha hasta:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(17, 31);
            label2.Name = "label2";
            label2.Size = new Size(75, 15);
            label2.TabIndex = 3;
            label2.Text = "Fecha desde:";
            // 
            // fechaHasta
            // 
            fechaHasta.Format = DateTimePickerFormat.Short;
            fechaHasta.Location = new Point(98, 66);
            fechaHasta.Name = "fechaHasta";
            fechaHasta.Size = new Size(84, 23);
            fechaHasta.TabIndex = 1;
            // 
            // fechaDesde
            // 
            fechaDesde.Format = DateTimePickerFormat.Short;
            fechaDesde.Location = new Point(98, 25);
            fechaDesde.Name = "fechaDesde";
            fechaDesde.Size = new Size(84, 23);
            fechaDesde.TabIndex = 0;
            // 
            // Producto
            // 
            Producto.Controls.Add(txtProducto);
            Producto.Controls.Add(label5);
            Producto.Controls.Add(btBuscar);
            Producto.Controls.Add(txtIdProducto);
            Producto.Controls.Add(label4);
            Producto.Location = new Point(550, 80);
            Producto.Name = "Producto";
            Producto.Size = new Size(200, 146);
            Producto.TabIndex = 3;
            Producto.TabStop = false;
            Producto.Text = "Producto";
            // 
            // txtProducto
            // 
            txtProducto.Enabled = false;
            txtProducto.Location = new Point(79, 72);
            txtProducto.Name = "txtProducto";
            txtProducto.Size = new Size(100, 23);
            txtProducto.TabIndex = 4;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(17, 75);
            label5.Name = "label5";
            label5.Size = new Size(56, 15);
            label5.TabIndex = 3;
            label5.Text = "Producto";
            // 
            // btBuscar
            // 
            btBuscar.Location = new Point(56, 107);
            btBuscar.Name = "btBuscar";
            btBuscar.Size = new Size(75, 23);
            btBuscar.TabIndex = 2;
            btBuscar.Text = "Buscar";
            btBuscar.UseVisualStyleBackColor = true;
            // 
            // txtIdProducto
            // 
            txtIdProducto.Enabled = false;
            txtIdProducto.Location = new Point(79, 39);
            txtIdProducto.Name = "txtIdProducto";
            txtIdProducto.Size = new Size(100, 23);
            txtIdProducto.TabIndex = 1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(4, 39);
            label4.Name = "label4";
            label4.Size = new Size(69, 15);
            label4.TabIndex = 0;
            label4.Text = "Id Producto";
            // 
            // Estadisticas
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(Producto);
            Controls.Add(Fechas);
            Controls.Add(Opciones);
            Controls.Add(label1);
            Name = "Estadisticas";
            Text = "Estadisticas";
            Opciones.ResumeLayout(false);
            Opciones.PerformLayout();
            Fechas.ResumeLayout(false);
            Fechas.PerformLayout();
            Producto.ResumeLayout(false);
            Producto.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private GroupBox Opciones;
        private RadioButton productoXmes;
        private RadioButton cincoMenosVendidos;
        private RadioButton diezMasVendidos;
        private GroupBox Fechas;
        private DateTimePicker fechaDesde;
        private Label label3;
        private Label label2;
        private DateTimePicker fechaHasta;
        private GroupBox Producto;
        private TextBox txtIdProducto;
        private Label label4;
        private TextBox txtProducto;
        private Label label5;
        private Button btBuscar;
    }
}