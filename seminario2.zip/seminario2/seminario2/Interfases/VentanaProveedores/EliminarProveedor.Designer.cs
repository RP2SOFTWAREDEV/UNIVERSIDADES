﻿namespace seminario2.Interfases.VentanaProveedores
{
    partial class EliminarProveedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgProveedores = new DataGridView();
            btCancelar = new Button();
            btEliminar = new Button();
            txtCuit = new TextBox();
            txtRazonSocial = new TextBox();
            txtDireccion = new TextBox();
            txtTelefono = new TextBox();
            txtEmail = new TextBox();
            txtNombre = new TextBox();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            txtIdProveedor = new TextBox();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgProveedores).BeginInit();
            SuspendLayout();
            // 
            // dgProveedores
            // 
            dgProveedores.AllowUserToAddRows = false;
            dgProveedores.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgProveedores.Location = new Point(408, 51);
            dgProveedores.Name = "dgProveedores";
            dgProveedores.ReadOnly = true;
            dgProveedores.RowTemplate.Height = 25;
            dgProveedores.Size = new Size(709, 298);
            dgProveedores.TabIndex = 50;
            dgProveedores.CellDoubleClick += dgProveedores_CellDoubleClick;
            // 
            // btCancelar
            // 
            btCancelar.Location = new Point(153, 353);
            btCancelar.Name = "btCancelar";
            btCancelar.Size = new Size(75, 23);
            btCancelar.TabIndex = 49;
            btCancelar.Text = "Cancelar";
            btCancelar.UseVisualStyleBackColor = true;
            btCancelar.Click += btCancelar_Click;
            // 
            // btEliminar
            // 
            btEliminar.Location = new Point(32, 353);
            btEliminar.Name = "btEliminar";
            btEliminar.Size = new Size(75, 23);
            btEliminar.TabIndex = 48;
            btEliminar.Text = "Eliminar";
            btEliminar.UseVisualStyleBackColor = true;
            btEliminar.Click += btEliminar_Click;
            // 
            // txtCuit
            // 
            txtCuit.Location = new Point(96, 289);
            txtCuit.Name = "txtCuit";
            txtCuit.ReadOnly = true;
            txtCuit.Size = new Size(168, 23);
            txtCuit.TabIndex = 47;
            // 
            // txtRazonSocial
            // 
            txtRazonSocial.Location = new Point(96, 254);
            txtRazonSocial.Name = "txtRazonSocial";
            txtRazonSocial.ReadOnly = true;
            txtRazonSocial.Size = new Size(304, 23);
            txtRazonSocial.TabIndex = 46;
            // 
            // txtDireccion
            // 
            txtDireccion.Location = new Point(96, 213);
            txtDireccion.Name = "txtDireccion";
            txtDireccion.ReadOnly = true;
            txtDireccion.Size = new Size(306, 23);
            txtDireccion.TabIndex = 45;
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(96, 184);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.ReadOnly = true;
            txtTelefono.Size = new Size(169, 23);
            txtTelefono.TabIndex = 44;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(96, 148);
            txtEmail.Name = "txtEmail";
            txtEmail.ReadOnly = true;
            txtEmail.Size = new Size(269, 23);
            txtEmail.TabIndex = 43;
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(96, 117);
            txtNombre.Name = "txtNombre";
            txtNombre.ReadOnly = true;
            txtNombre.Size = new Size(269, 23);
            txtNombre.TabIndex = 42;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(12, 292);
            label7.Name = "label7";
            label7.Size = new Size(29, 15);
            label7.TabIndex = 41;
            label7.Text = "Cuit";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(11, 257);
            label6.Name = "label6";
            label6.Size = new Size(73, 15);
            label6.TabIndex = 40;
            label6.Text = "Razón Social";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(11, 213);
            label5.Name = "label5";
            label5.Size = new Size(57, 15);
            label5.TabIndex = 39;
            label5.Text = "Dirección";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(11, 187);
            label4.Name = "label4";
            label4.Size = new Size(52, 15);
            label4.TabIndex = 38;
            label4.Text = "Teléfono";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 156);
            label3.Name = "label3";
            label3.Size = new Size(36, 15);
            label3.TabIndex = 37;
            label3.Text = "Email";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 117);
            label2.Name = "label2";
            label2.Size = new Size(51, 15);
            label2.TabIndex = 36;
            label2.Text = "Nombre";
            // 
            // txtIdProveedor
            // 
            txtIdProveedor.Location = new Point(96, 78);
            txtIdProveedor.Name = "txtIdProveedor";
            txtIdProveedor.ReadOnly = true;
            txtIdProveedor.Size = new Size(84, 23);
            txtIdProveedor.TabIndex = 35;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 78);
            label1.Name = "label1";
            label1.Size = new Size(74, 15);
            label1.TabIndex = 34;
            label1.Text = "Id Proveedor";
            // 
            // EliminarProveedor
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1205, 450);
            Controls.Add(dgProveedores);
            Controls.Add(btCancelar);
            Controls.Add(btEliminar);
            Controls.Add(txtCuit);
            Controls.Add(txtRazonSocial);
            Controls.Add(txtDireccion);
            Controls.Add(txtTelefono);
            Controls.Add(txtEmail);
            Controls.Add(txtNombre);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtIdProveedor);
            Controls.Add(label1);
            Name = "EliminarProveedor";
            Text = "EliminarProveedor";
            Load += EliminarProveedor_Load;
            ((System.ComponentModel.ISupportInitialize)dgProveedores).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgProveedores;
        private Button btCancelar;
        private Button btEliminar;
        private TextBox txtCuit;
        private TextBox txtRazonSocial;
        private TextBox txtDireccion;
        private TextBox txtTelefono;
        private TextBox txtEmail;
        private TextBox txtNombre;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox txtIdProveedor;
        private Label label1;
    }
}