﻿using seminario2.Acceso_a_Datos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace seminario2.Interfases.VentanaProveedores
{
    public partial class ConsultarProveedor : Form
    {
        public ConsultarProveedor()
        {
            InitializeComponent();
        }

        private void btBuscar_Click(object sender, EventArgs e)
        {
            string nombreProveedor = txtNombre.Text;
            if (nombreProveedor != "")
            {
                dgvProveedores.DataSource = ProveedorDAO.BuscarPorCampo("nombre", nombreProveedor);
            }

            string razonSocial = txtRazonSocial.Text;
            if (razonSocial != "")
            {
                dgvProveedores.DataSource = ProveedorDAO.BuscarPorCampo("razon_social", razonSocial);
            }

            txtNombre.Text = "";
            txtRazonSocial.Text = "";
        }

        private void ConsultarProveedor_Load(object sender, EventArgs e)
        {
            dgvProveedores.DataSource = ProveedorDAO.TraerTodos();

        }

        private void dgvProveedores_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int numeroFila = e.RowIndex;
            txtIdProveedor.Text = dgvProveedores.Rows[numeroFila].Cells[0].Value.ToString();
            txtNombre.Text = dgvProveedores.Rows[numeroFila].Cells[1].Value.ToString();
            txtRazonSocial.Text = dgvProveedores.Rows[numeroFila].Cells[5].Value.ToString();
            txtTelefono.Text = dgvProveedores.Rows[numeroFila].Cells[3].Value.ToString();
        }

        private void btRetornar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
