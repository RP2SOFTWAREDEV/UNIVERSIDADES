﻿using seminario2.Acceso_a_Datos;
using seminario2.Clases_de_Entidad;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace seminario2.Interfases.VentanaProveedores
{
    public partial class CargarProveedor : Form
    {
        public CargarProveedor()
        {
            InitializeComponent();
        }

        private void CargarProveedor_Load(object sender, EventArgs e)
        {
            int idProveedor = ProveedorDAO.ObtenerProximoId();
            txtIdProveedor.Text = idProveedor.ToString();
            RecargarTabla();
        }

        private void btBorrar_Click(object sender, EventArgs e)
        {
            txtIdProveedor.Text = "";
            txtNombre.Text = "";
            txtEmail.Text = "";
            txtTelefono.Text = "";
            txtDireccion.Text = "";
            txtRazonSocial.Text = "";
            txtCuit.Text = "";
        }

        private void btGuardar_Click(object sender, EventArgs e)
        {
            int idProveedor = Convert.ToInt32(txtIdProveedor.Text);
            string nombre = txtNombre.Text;
            string email = txtEmail.Text;
            string telefono = txtTelefono.Text;
            string direccion = txtDireccion.Text;
            string razonSocial = txtRazonSocial.Text;
            decimal cuit = Convert.ToDecimal(txtCuit.Text);

            Proveedor proveedor = new Proveedor();
            proveedor.Set_idProveedor(idProveedor);
            proveedor.Set_nombre(nombre);
            proveedor.Set_email(email);
            proveedor.Set_telefono(telefono);
            proveedor.Set_direccion(direccion);
            proveedor.Set_razonSocial(razonSocial);
            proveedor.Set_cuit(cuit);

            ProveedorDAO.InsertarUno(proveedor);
            MessageBox.Show("El proveedor se cargó exitosamente");
            btBorrar_Click(sender, e);
            RecargarTabla();

        }
        private void RecargarTabla()
        {
            dgProveedores.DataSource = ProveedorDAO.TraerTodos();

        }
    }
}
