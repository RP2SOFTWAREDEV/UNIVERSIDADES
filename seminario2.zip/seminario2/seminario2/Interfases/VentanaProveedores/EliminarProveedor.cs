﻿using seminario2.Acceso_a_Datos;
using seminario2.Clases_de_Entidad;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace seminario2.Interfases.VentanaProveedores
{
    public partial class EliminarProveedor : Form
    {
        public EliminarProveedor()
        {
            InitializeComponent();
        }



        private void EliminarProveedor_Load(object sender, EventArgs e)
        {
            dgProveedores.DataSource = ProveedorDAO.TraerTodos();
        }

        private void dgProveedores_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int numeroFila = e.RowIndex;
            txtIdProveedor.Text = dgProveedores.Rows[numeroFila].Cells[0].Value.ToString();
            txtNombre.Text = dgProveedores.Rows[numeroFila].Cells[1].Value.ToString();
            txtEmail.Text = dgProveedores.Rows[numeroFila].Cells[2].Value.ToString();
            txtTelefono.Text = dgProveedores.Rows[numeroFila].Cells[3].Value.ToString();
            txtDireccion.Text = dgProveedores.Rows[numeroFila].Cells[4].Value.ToString();
            txtRazonSocial.Text = dgProveedores.Rows[numeroFila].Cells[5].Value.ToString();
            txtCuit.Text = dgProveedores.Rows[numeroFila].Cells[6].Value.ToString();
        }

        private void btEliminar_Click(object sender, EventArgs e)
        {
            DialogResult respuesta = MessageBox.Show("¿Está seguro de querer eliminar al proveedor " + txtNombre.Text +"-" + txtRazonSocial.Text+"?", "Eliminar Proveedor", MessageBoxButtons.YesNo);
            if (respuesta == DialogResult.Yes)
            {
                int idProveedor = Convert.ToInt32(txtIdProveedor.Text);
                ProveedorDAO.EliminarUno(idProveedor);
                MessageBox.Show("El proveedor se eliminó correctamente");
                LimpiarControladores();
                RecargarTabla();
            }
        }
        private void LimpiarControladores()
        {
            txtIdProveedor.Text = "";
            txtNombre.Text = "";
            txtEmail.Text = "";
            txtTelefono.Text = "";
            txtDireccion.Text = "";
            txtRazonSocial.Text = "";
            txtCuit.Text = "";
        }
        private void RecargarTabla()
        {
            dgProveedores.DataSource = ProveedorDAO.TraerTodos();

        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

}
