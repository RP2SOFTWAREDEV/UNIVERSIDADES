﻿namespace seminario2.Interfases.VentanaProveedores
{
    partial class CargarProveedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtIdProveedor = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            txtNombre = new TextBox();
            txtEmail = new TextBox();
            txtTelefono = new TextBox();
            txtDireccion = new TextBox();
            txtRazonSocial = new TextBox();
            txtCuit = new TextBox();
            btGuardar = new Button();
            btBorrar = new Button();
            dgProveedores = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgProveedores).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(27, 23);
            label1.Name = "label1";
            label1.Size = new Size(74, 15);
            label1.TabIndex = 0;
            label1.Text = "Id Proveedor";
            // 
            // txtIdProveedor
            // 
            txtIdProveedor.Location = new Point(116, 20);
            txtIdProveedor.Name = "txtIdProveedor";
            txtIdProveedor.Size = new Size(84, 23);
            txtIdProveedor.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(27, 56);
            label2.Name = "label2";
            label2.Size = new Size(51, 15);
            label2.TabIndex = 2;
            label2.Text = "Nombre";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(27, 90);
            label3.Name = "label3";
            label3.Size = new Size(36, 15);
            label3.TabIndex = 3;
            label3.Text = "Email";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(26, 129);
            label4.Name = "label4";
            label4.Size = new Size(52, 15);
            label4.TabIndex = 4;
            label4.Text = "Teléfono";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(27, 166);
            label5.Name = "label5";
            label5.Size = new Size(57, 15);
            label5.TabIndex = 5;
            label5.Text = "Dirección";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(28, 202);
            label6.Name = "label6";
            label6.Size = new Size(73, 15);
            label6.TabIndex = 6;
            label6.Text = "Razón Social";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(34, 237);
            label7.Name = "label7";
            label7.Size = new Size(29, 15);
            label7.TabIndex = 7;
            label7.Text = "Cuit";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(116, 56);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(269, 23);
            txtNombre.TabIndex = 8;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(116, 91);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(269, 23);
            txtEmail.TabIndex = 9;
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(117, 129);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(169, 23);
            txtTelefono.TabIndex = 10;
            // 
            // txtDireccion
            // 
            txtDireccion.Location = new Point(116, 165);
            txtDireccion.Name = "txtDireccion";
            txtDireccion.Size = new Size(306, 23);
            txtDireccion.TabIndex = 11;
            // 
            // txtRazonSocial
            // 
            txtRazonSocial.Location = new Point(118, 199);
            txtRazonSocial.Name = "txtRazonSocial";
            txtRazonSocial.Size = new Size(304, 23);
            txtRazonSocial.TabIndex = 12;
            // 
            // txtCuit
            // 
            txtCuit.Location = new Point(118, 237);
            txtCuit.Name = "txtCuit";
            txtCuit.Size = new Size(168, 23);
            txtCuit.TabIndex = 13;
            // 
            // btGuardar
            // 
            btGuardar.Location = new Point(76, 298);
            btGuardar.Name = "btGuardar";
            btGuardar.Size = new Size(75, 23);
            btGuardar.TabIndex = 14;
            btGuardar.Text = "Guardar";
            btGuardar.UseVisualStyleBackColor = true;
            btGuardar.Click += btGuardar_Click;
            // 
            // btBorrar
            // 
            btBorrar.Location = new Point(197, 298);
            btBorrar.Name = "btBorrar";
            btBorrar.Size = new Size(75, 23);
            btBorrar.TabIndex = 15;
            btBorrar.Text = "Borrar";
            btBorrar.UseVisualStyleBackColor = true;
            btBorrar.Click += btBorrar_Click;
            // 
            // dgProveedores
            // 
            dgProveedores.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgProveedores.Location = new Point(428, 20);
            dgProveedores.Name = "dgProveedores";
            dgProveedores.RowTemplate.Height = 25;
            dgProveedores.Size = new Size(709, 298);
            dgProveedores.TabIndex = 16;
            // 
            // CargarProveedor
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1149, 450);
            Controls.Add(dgProveedores);
            Controls.Add(btBorrar);
            Controls.Add(btGuardar);
            Controls.Add(txtCuit);
            Controls.Add(txtRazonSocial);
            Controls.Add(txtDireccion);
            Controls.Add(txtTelefono);
            Controls.Add(txtEmail);
            Controls.Add(txtNombre);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtIdProveedor);
            Controls.Add(label1);
            Name = "CargarProveedor";
            Text = "CargarProveedor";
            Load += CargarProveedor_Load;
            ((System.ComponentModel.ISupportInitialize)dgProveedores).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtIdProveedor;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private TextBox txtNombre;
        private TextBox txtEmail;
        private TextBox txtTelefono;
        private TextBox txtDireccion;
        private TextBox txtRazonSocial;
        private TextBox txtCuit;
        private Button btGuardar;
        private Button btBorrar;
        private DataGridView dgProveedores;
    }
}