﻿namespace seminario2.Interfases.VentanaProveedores
{
    partial class ConsultarProveedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvProveedores = new DataGridView();
            label1 = new Label();
            txtIdProveedor = new TextBox();
            txtNombre = new TextBox();
            label2 = new Label();
            btBuscar = new Button();
            label3 = new Label();
            txtRazonSocial = new TextBox();
            btRetornar = new Button();
            label4 = new Label();
            txtTelefono = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dgvProveedores).BeginInit();
            SuspendLayout();
            // 
            // dgvProveedores
            // 
            dgvProveedores.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProveedores.Location = new Point(351, 34);
            dgvProveedores.Name = "dgvProveedores";
            dgvProveedores.ReadOnly = true;
            dgvProveedores.RowTemplate.Height = 25;
            dgvProveedores.Size = new Size(628, 268);
            dgvProveedores.TabIndex = 0;
            dgvProveedores.CellContentDoubleClick += dgvProveedores_CellContentDoubleClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(45, 55);
            label1.Name = "label1";
            label1.Size = new Size(74, 15);
            label1.TabIndex = 1;
            label1.Text = "Id proveedor";
            // 
            // txtIdProveedor
            // 
            txtIdProveedor.Enabled = false;
            txtIdProveedor.Location = new Point(125, 52);
            txtIdProveedor.Name = "txtIdProveedor";
            txtIdProveedor.Size = new Size(64, 23);
            txtIdProveedor.TabIndex = 2;
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(125, 104);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(207, 23);
            txtNombre.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(50, 112);
            label2.Name = "label2";
            label2.Size = new Size(51, 15);
            label2.TabIndex = 4;
            label2.Text = "Nombre";
            // 
            // btBuscar
            // 
            btBuscar.Location = new Point(309, 329);
            btBuscar.Name = "btBuscar";
            btBuscar.Size = new Size(75, 23);
            btBuscar.TabIndex = 5;
            btBuscar.Text = "Buscar";
            btBuscar.UseVisualStyleBackColor = true;
            btBuscar.Click += btBuscar_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(50, 170);
            label3.Name = "label3";
            label3.Size = new Size(72, 15);
            label3.TabIndex = 6;
            label3.Text = "Razón social";
            // 
            // txtRazonSocial
            // 
            txtRazonSocial.Location = new Point(125, 167);
            txtRazonSocial.Name = "txtRazonSocial";
            txtRazonSocial.Size = new Size(207, 23);
            txtRazonSocial.TabIndex = 7;
            // 
            // btRetornar
            // 
            btRetornar.Location = new Point(170, 329);
            btRetornar.Name = "btRetornar";
            btRetornar.Size = new Size(75, 23);
            btRetornar.TabIndex = 8;
            btRetornar.Text = "Retornar";
            btRetornar.UseVisualStyleBackColor = true;
            btRetornar.Visible = false;
            btRetornar.Click += btRetornar_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(52, 231);
            label4.Name = "label4";
            label4.Size = new Size(52, 15);
            label4.TabIndex = 9;
            label4.Text = "Teléfono";
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(125, 223);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(207, 23);
            txtTelefono.TabIndex = 10;
            // 
            // ConsultarProveedor
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1010, 450);
            Controls.Add(txtTelefono);
            Controls.Add(label4);
            Controls.Add(btRetornar);
            Controls.Add(txtRazonSocial);
            Controls.Add(label3);
            Controls.Add(btBuscar);
            Controls.Add(label2);
            Controls.Add(txtNombre);
            Controls.Add(txtIdProveedor);
            Controls.Add(label1);
            Controls.Add(dgvProveedores);
            Name = "ConsultarProveedor";
            Text = "ConsultarProveedor";
            Load += ConsultarProveedor_Load;
            ((System.ComponentModel.ISupportInitialize)dgvProveedores).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvProveedores;
        private Label label1;
        private Label label2;
        private Button btBuscar;
        private Label label3;
        public TextBox txtIdProveedor;
        public TextBox txtNombre;
        public TextBox txtRazonSocial;
        private Label label4;
        public TextBox txtTelefono;
        public Button btRetornar;
    }
}