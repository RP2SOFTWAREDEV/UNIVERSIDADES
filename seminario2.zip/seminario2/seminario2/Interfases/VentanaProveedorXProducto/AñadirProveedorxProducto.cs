﻿using seminario2.Acceso_a_Datos;
using seminario2.Controladores;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace seminario2.Interfases.VentanaProveedorXProducto
{
    public partial class AñadirProveedorxProducto : Form
    {
        public AñadirProveedorxProducto()
        {
            InitializeComponent();
        }

        private void btProducto_Click(object sender, EventArgs e)
        {
            GestorTraerProducto gestor = new GestorTraerProducto(this);
            gestor.LlenarControladores();
        }

        private void btSeleccionarProveedor_Click(object sender, EventArgs e)
        {
            GestorTraerProveedor gestor = new GestorTraerProveedor(this);
            gestor.LlenarControladores();
        }

        private void btAñadir_Click(object sender, EventArgs e)
        {
            int id_proveedor;
            string codigo_barras;
            double precio;
            id_proveedor = Convert.ToInt32(txtIdProveedor.Text);
            codigo_barras = txtCodigoBarras.Text;
            precio = Convert.ToDouble(txtPrecioxUnidad.Text);
            CatalogoDAO.InsertarUno(id_proveedor, codigo_barras, precio);
            LlenarGrilla();
        }
        private void LlenarGrilla()
        {
            dgProveedores.DataSource = CatalogoDAO.TraerInfo();
        }

        private void AñadirProveedorxProducto_Load(object sender, EventArgs e)
        {
            LlenarGrilla();
        }
    }
}
