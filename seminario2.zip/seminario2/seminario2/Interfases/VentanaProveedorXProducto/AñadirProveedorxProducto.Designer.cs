﻿namespace seminario2.Interfases.VentanaProveedorXProducto
{
    partial class AñadirProveedorxProducto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btProducto = new Button();
            btSeleccionarProveedor = new Button();
            btAñadir = new Button();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtTelefono = new TextBox();
            txtRazonSocial = new TextBox();
            txtProveedor = new TextBox();
            txtPrecioxUnidad = new TextBox();
            txtProducto = new TextBox();
            txtCodigoBarras = new TextBox();
            dgProveedores = new DataGridView();
            txtIdProveedor = new TextBox();
            label7 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgProveedores).BeginInit();
            SuspendLayout();
            // 
            // btProducto
            // 
            btProducto.Location = new Point(583, 354);
            btProducto.Name = "btProducto";
            btProducto.Size = new Size(142, 23);
            btProducto.TabIndex = 31;
            btProducto.Text = "Seleccionar Producto";
            btProducto.UseVisualStyleBackColor = true;
            btProducto.Click += btProducto_Click;
            // 
            // btSeleccionarProveedor
            // 
            btSeleccionarProveedor.Location = new Point(403, 354);
            btSeleccionarProveedor.Name = "btSeleccionarProveedor";
            btSeleccionarProveedor.Size = new Size(139, 23);
            btSeleccionarProveedor.TabIndex = 30;
            btSeleccionarProveedor.Text = "Seleccionar Proveedor";
            btSeleccionarProveedor.UseVisualStyleBackColor = true;
            btSeleccionarProveedor.Click += btSeleccionarProveedor_Click;
            // 
            // btAñadir
            // 
            btAñadir.Location = new Point(197, 354);
            btAñadir.Name = "btAñadir";
            btAñadir.Size = new Size(134, 23);
            btAñadir.TabIndex = 29;
            btAñadir.Text = "Añadir";
            btAñadir.UseVisualStyleBackColor = true;
            btAñadir.Click += btAñadir_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(88, 282);
            label6.Name = "label6";
            label6.Size = new Size(52, 15);
            label6.TabIndex = 28;
            label6.Text = "Teléfono";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(84, 238);
            label5.Name = "label5";
            label5.Size = new Size(72, 15);
            label5.TabIndex = 27;
            label5.Text = "Razón social";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(79, 199);
            label4.Name = "label4";
            label4.Size = new Size(61, 15);
            label4.TabIndex = 26;
            label4.Text = "Proveedor";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(67, 126);
            label3.Name = "label3";
            label3.Size = new Size(89, 15);
            label3.TabIndex = 25;
            label3.Text = "Precio x unidad";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(79, 88);
            label2.Name = "label2";
            label2.Size = new Size(56, 15);
            label2.TabIndex = 24;
            label2.Text = "Producto";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(75, 54);
            label1.Name = "label1";
            label1.Size = new Size(81, 15);
            label1.TabIndex = 23;
            label1.Text = "Código barras";
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(182, 279);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(167, 23);
            txtTelefono.TabIndex = 22;
            // 
            // txtRazonSocial
            // 
            txtRazonSocial.Location = new Point(182, 235);
            txtRazonSocial.Name = "txtRazonSocial";
            txtRazonSocial.Size = new Size(167, 23);
            txtRazonSocial.TabIndex = 21;
            // 
            // txtProveedor
            // 
            txtProveedor.Location = new Point(182, 196);
            txtProveedor.Name = "txtProveedor";
            txtProveedor.Size = new Size(167, 23);
            txtProveedor.TabIndex = 20;
            // 
            // txtPrecioxUnidad
            // 
            txtPrecioxUnidad.Location = new Point(182, 126);
            txtPrecioxUnidad.Name = "txtPrecioxUnidad";
            txtPrecioxUnidad.Size = new Size(100, 23);
            txtPrecioxUnidad.TabIndex = 19;
            // 
            // txtProducto
            // 
            txtProducto.Location = new Point(180, 88);
            txtProducto.Name = "txtProducto";
            txtProducto.ReadOnly = true;
            txtProducto.Size = new Size(167, 23);
            txtProducto.TabIndex = 18;
            // 
            // txtCodigoBarras
            // 
            txtCodigoBarras.Location = new Point(182, 54);
            txtCodigoBarras.Name = "txtCodigoBarras";
            txtCodigoBarras.ReadOnly = true;
            txtCodigoBarras.Size = new Size(167, 23);
            txtCodigoBarras.TabIndex = 17;
            // 
            // dgProveedores
            // 
            dgProveedores.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgProveedores.Location = new Point(355, 12);
            dgProveedores.Name = "dgProveedores";
            dgProveedores.RowTemplate.Height = 25;
            dgProveedores.Size = new Size(433, 290);
            dgProveedores.TabIndex = 16;
            // 
            // txtIdProveedor
            // 
            txtIdProveedor.Location = new Point(180, 162);
            txtIdProveedor.Name = "txtIdProveedor";
            txtIdProveedor.Size = new Size(100, 23);
            txtIdProveedor.TabIndex = 32;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(75, 162);
            label7.Name = "label7";
            label7.Size = new Size(74, 15);
            label7.TabIndex = 33;
            label7.Text = "Id Proveedor";
            // 
            // AñadirProveedorxProducto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label7);
            Controls.Add(txtIdProveedor);
            Controls.Add(btProducto);
            Controls.Add(btSeleccionarProveedor);
            Controls.Add(btAñadir);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtTelefono);
            Controls.Add(txtRazonSocial);
            Controls.Add(txtProveedor);
            Controls.Add(txtPrecioxUnidad);
            Controls.Add(txtProducto);
            Controls.Add(txtCodigoBarras);
            Controls.Add(dgProveedores);
            Name = "AñadirProveedorxProducto";
            Text = "AñadirProveedorxProducto";
            Load += AñadirProveedorxProducto_Load;
            ((System.ComponentModel.ISupportInitialize)dgProveedores).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btProducto;
        private Button btSeleccionarProveedor;
        private Button btAñadir;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtPrecioxUnidad;
        private DataGridView dgProveedores;
        public TextBox txtProducto;
        public TextBox txtCodigoBarras;
        public TextBox txtIdProveedor;
        private Label label7;
        public TextBox txtTelefono;
        public TextBox txtRazonSocial;
        public TextBox txtProveedor;
    }
}