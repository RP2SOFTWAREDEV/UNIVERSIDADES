﻿namespace seminario2.Interfases.VentanaProveedorXProducto
{
    partial class EliminarProveedorxProducto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgProveedores = new DataGridView();
            txtCodigoBarras = new TextBox();
            txtProducto = new TextBox();
            txtPrecioxUnidad = new TextBox();
            txtProveedor = new TextBox();
            txtRazonSocial = new TextBox();
            txtTelefono = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            btAñadir = new Button();
            btSeleccionarProveedor = new Button();
            btProducto = new Button();
            ((System.ComponentModel.ISupportInitialize)dgProveedores).BeginInit();
            SuspendLayout();
            // 
            // dgProveedores
            // 
            dgProveedores.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgProveedores.Location = new Point(358, 59);
            dgProveedores.Name = "dgProveedores";
            dgProveedores.RowTemplate.Height = 25;
            dgProveedores.Size = new Size(307, 211);
            dgProveedores.TabIndex = 0;
            // 
            // txtCodigoBarras
            // 
            txtCodigoBarras.Location = new Point(122, 59);
            txtCodigoBarras.Name = "txtCodigoBarras";
            txtCodigoBarras.Size = new Size(167, 23);
            txtCodigoBarras.TabIndex = 1;
            // 
            // txtProducto
            // 
            txtProducto.Location = new Point(122, 101);
            txtProducto.Name = "txtProducto";
            txtProducto.Size = new Size(167, 23);
            txtProducto.TabIndex = 2;
            // 
            // txtPrecioxUnidad
            // 
            txtPrecioxUnidad.Location = new Point(122, 140);
            txtPrecioxUnidad.Name = "txtPrecioxUnidad";
            txtPrecioxUnidad.Size = new Size(100, 23);
            txtPrecioxUnidad.TabIndex = 3;
            // 
            // txtProveedor
            // 
            txtProveedor.Location = new Point(122, 181);
            txtProveedor.Name = "txtProveedor";
            txtProveedor.Size = new Size(167, 23);
            txtProveedor.TabIndex = 4;
            // 
            // txtRazonSocial
            // 
            txtRazonSocial.Location = new Point(122, 220);
            txtRazonSocial.Name = "txtRazonSocial";
            txtRazonSocial.Size = new Size(167, 23);
            txtRazonSocial.TabIndex = 5;
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(122, 264);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(167, 23);
            txtTelefono.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(15, 63);
            label1.Name = "label1";
            label1.Size = new Size(81, 15);
            label1.TabIndex = 7;
            label1.Text = "Código barras";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(20, 95);
            label2.Name = "label2";
            label2.Size = new Size(56, 15);
            label2.TabIndex = 8;
            label2.Text = "Producto";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(19, 140);
            label3.Name = "label3";
            label3.Size = new Size(89, 15);
            label3.TabIndex = 9;
            label3.Text = "Precio x unidad";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(19, 184);
            label4.Name = "label4";
            label4.Size = new Size(61, 15);
            label4.TabIndex = 10;
            label4.Text = "Proveedor";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(24, 223);
            label5.Name = "label5";
            label5.Size = new Size(72, 15);
            label5.TabIndex = 11;
            label5.Text = "Razón social";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(28, 267);
            label6.Name = "label6";
            label6.Size = new Size(52, 15);
            label6.TabIndex = 12;
            label6.Text = "Teléfono";
            // 
            // btAñadir
            // 
            btAñadir.Location = new Point(137, 339);
            btAñadir.Name = "btAñadir";
            btAñadir.Size = new Size(134, 23);
            btAñadir.TabIndex = 13;
            btAñadir.Text = "Añadir";
            btAñadir.UseVisualStyleBackColor = true;
            // 
            // btSeleccionarProveedor
            // 
            btSeleccionarProveedor.Location = new Point(343, 339);
            btSeleccionarProveedor.Name = "btSeleccionarProveedor";
            btSeleccionarProveedor.Size = new Size(139, 23);
            btSeleccionarProveedor.TabIndex = 14;
            btSeleccionarProveedor.Text = "Seleccionar Proveedor";
            btSeleccionarProveedor.UseVisualStyleBackColor = true;
            // 
            // btProducto
            // 
            btProducto.Location = new Point(523, 339);
            btProducto.Name = "btProducto";
            btProducto.Size = new Size(142, 23);
            btProducto.TabIndex = 15;
            btProducto.Text = "Seleccionar Producto";
            btProducto.UseVisualStyleBackColor = true;
            // 
            // EliminarProveedorxProducto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btProducto);
            Controls.Add(btSeleccionarProveedor);
            Controls.Add(btAñadir);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtTelefono);
            Controls.Add(txtRazonSocial);
            Controls.Add(txtProveedor);
            Controls.Add(txtPrecioxUnidad);
            Controls.Add(txtProducto);
            Controls.Add(txtCodigoBarras);
            Controls.Add(dgProveedores);
            Name = "EliminarProveedorxProducto";
            Text = "EliminarProveedorxProducto";
            ((System.ComponentModel.ISupportInitialize)dgProveedores).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgProveedores;
        private TextBox txtCodigoBarras;
        private TextBox txtProducto;
        private TextBox txtPrecioxUnidad;
        private TextBox txtProveedor;
        private TextBox txtRazonSocial;
        private TextBox txtTelefono;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Button btAñadir;
        private Button btSeleccionarProveedor;
        private Button btProducto;
    }
}