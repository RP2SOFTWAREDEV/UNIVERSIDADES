﻿using seminario2.Acceso_a_Datos;
using seminario2.Interfases.VentanaUsuario;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace seminario2.Interfases.VentanaFacturas
{
    public partial class EliminarFactura : Form
    {
        public EliminarFactura()
        {
            InitializeComponent();
        }

        private void txtNroFactura_TextChanged(object sender, EventArgs e)
        {
            if (txtNroFactura.Text == "")
            {
                btEliminar.Enabled = false;
            }
            else
            {
                btEliminar.Enabled = true;
            }
        }

        private void btEliminar_Click(object sender, EventArgs e)
        {
            int nro_factura = Convert.ToInt32(txtNroFactura.Text);
            MessageBox.Show(""+Principal.idUsuario + "," + nro_factura);
            FacturaDAO.EliminarFactura(Principal.idUsuario, nro_factura);
            MessageBox.Show("La factura fue eliminada correctamente");
            dgEliminarFactura.DataSource = FacturaDAO.TraerTodos();
        }

        private void EliminarFactura_Load(object sender, EventArgs e)
        {
            dgEliminarFactura.DataSource = FacturaDAO.TraerTodos();
        }

        private void dgEliminarFactura_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int id;
            id = (int)dgEliminarFactura.Rows[e.RowIndex].Cells[0].Value;
            txtNroFactura.Text = id.ToString();
        }
    }
}
