﻿namespace seminario2.Interfases.VentanaFacturas
{
    partial class EliminarFactura
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNroFactura = new TextBox();
            label1 = new Label();
            dgEliminarFactura = new DataGridView();
            btEliminar = new Button();
            btCancelar = new Button();
            ((System.ComponentModel.ISupportInitialize)dgEliminarFactura).BeginInit();
            SuspendLayout();
            // 
            // txtNroFactura
            // 
            txtNroFactura.Enabled = false;
            txtNroFactura.Location = new Point(185, 27);
            txtNroFactura.Name = "txtNroFactura";
            txtNroFactura.Size = new Size(55, 23);
            txtNroFactura.TabIndex = 0;
            txtNroFactura.TextChanged += txtNroFactura_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(110, 30);
            label1.Name = "label1";
            label1.Size = new Size(69, 15);
            label1.TabIndex = 1;
            label1.Text = "Nro Factura";
            // 
            // dgEliminarFactura
            // 
            dgEliminarFactura.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgEliminarFactura.Location = new Point(121, 56);
            dgEliminarFactura.Name = "dgEliminarFactura";
            dgEliminarFactura.RowTemplate.Height = 25;
            dgEliminarFactura.Size = new Size(508, 216);
            dgEliminarFactura.TabIndex = 2;
            dgEliminarFactura.CellContentClick += dgEliminarFactura_CellContentClick;
            // 
            // btEliminar
            // 
            btEliminar.Enabled = false;
            btEliminar.Location = new Point(299, 291);
            btEliminar.Name = "btEliminar";
            btEliminar.Size = new Size(75, 23);
            btEliminar.TabIndex = 3;
            btEliminar.Text = "Eliminar";
            btEliminar.UseVisualStyleBackColor = true;
            btEliminar.Click += btEliminar_Click;
            // 
            // btCancelar
            // 
            btCancelar.Location = new Point(438, 291);
            btCancelar.Name = "btCancelar";
            btCancelar.Size = new Size(75, 23);
            btCancelar.TabIndex = 4;
            btCancelar.Text = "Cancelar";
            btCancelar.UseVisualStyleBackColor = true;
            // 
            // EliminarFactura
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btCancelar);
            Controls.Add(btEliminar);
            Controls.Add(dgEliminarFactura);
            Controls.Add(label1);
            Controls.Add(txtNroFactura);
            Name = "EliminarFactura";
            Text = "EliminarFactura";
            Load += EliminarFactura_Load;
            ((System.ComponentModel.ISupportInitialize)dgEliminarFactura).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNroFactura;
        private Label label1;
        private DataGridView dgEliminarFactura;
        private Button btEliminar;
        private Button btCancelar;
    }
}