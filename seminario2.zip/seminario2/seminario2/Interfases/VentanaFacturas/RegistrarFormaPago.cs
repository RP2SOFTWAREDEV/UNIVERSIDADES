﻿using seminario2.Acceso_a_Datos;
using seminario2.Clases_de_Entidad;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace seminario2.Interfases.VentanaFacturas
{
    public partial class RegistrarFormaPago : Form
    {
        Factura factura;
        double total;
        public RegistrarFormaPago(Factura f)
        {
            InitializeComponent();
            factura = f;
            total = f.calcularTotal();
        }

        private void RegistrarFormaPago_Load(object sender, EventArgs e)
        {
            lbDescripcionFormaPago.Text = factura.MostrarItemsPago();

            cbFormaPago.DataSource = FormadePagoDAO.TraerTodos();
            cbFormaPago.ValueMember = "id_forma_pago";
            cbFormaPago.DisplayMember = "nombre";
            txtNroFactura.Text = factura.Get_NroFactura().ToString();
        }
        private void GuardarFactura()
        {
            FacturaDAO.InsertarUno(factura);
            MessageBox.Show("se cargó correctamente la factura");
            this.Close();
        }

        private void btAceptar_Click(object sender, EventArgs e)
        {
            double monto = Convert.ToDouble(txtMonto.Text);
            //validamos que el monto no se exceda y si se excede a la diferencia la dejaremos como vuelto
            if (monto > total)
            {
                double vuelto = monto - total;
                txtVuelto.Text = vuelto.ToString();
                monto -= vuelto;
               
            }
            total -= monto;


            switch (cbFormaPago.SelectedValue)
            {
                case 1:
                    factura.AñadirPagoEfectivo(monto);
                    break;
                case 2:
                    factura.AñadirPagoDebito(monto);
                    break;
                case 3:
                    factura.AñadirPagoFiado(monto);
                    break;
                case 4:
                    factura.AñadirPagoCredito(monto);
                    break;
            }
            lbDescripcionFormaPago.Text = factura.MostrarItemsPago();
            if (total == 0)
            {
                GuardarFactura();
            }

        }
    }
}
