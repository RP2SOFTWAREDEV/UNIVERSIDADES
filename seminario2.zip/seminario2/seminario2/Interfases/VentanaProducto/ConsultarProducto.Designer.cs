﻿namespace seminario2.Interfases.VentanaProducto
{
    partial class ConsultarProducto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            label1 = new Label();
            dgProductos = new DataGridView();
            txtProducto = new TextBox();
            txtBuscar = new Button();
            gbFiltros = new GroupBox();
            rbCodigoBarras = new RadioButton();
            rbCategoria = new RadioButton();
            rbNombre = new RadioButton();
            gbCategoria = new GroupBox();
            cbCategoria = new ComboBox();
            label2 = new Label();
            gbCodigoBarras = new GroupBox();
            txtCodigoBarras = new TextBox();
            label3 = new Label();
            gbNombre = new GroupBox();
            label4 = new Label();
            txtId = new TextBox();
            label5 = new Label();
            txtNombreProducto = new TextBox();
            btAñadir = new Button();
            gbDatosProducto = new GroupBox();
            btRetornarProducto = new Button();
            ((System.ComponentModel.ISupportInitialize)dgProductos).BeginInit();
            gbFiltros.SuspendLayout();
            gbCategoria.SuspendLayout();
            gbCodigoBarras.SuspendLayout();
            gbNombre.SuspendLayout();
            gbDatosProducto.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 24);
            label1.Name = "label1";
            label1.Size = new Size(122, 15);
            label1.TabIndex = 0;
            label1.Text = "Nombre del Producto";
            // 
            // dgProductos
            // 
            dgProductos.AllowUserToAddRows = false;
            dgProductos.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dgProductos.BackgroundColor = SystemColors.Control;
            dgProductos.BorderStyle = BorderStyle.None;
            dgProductos.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(255, 255, 192);
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dgProductos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dgProductos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dgProductos.DefaultCellStyle = dataGridViewCellStyle2;
            dgProductos.Location = new Point(0, 300);
            dgProductos.Name = "dgProductos";
            dgProductos.RowTemplate.Height = 25;
            dgProductos.Size = new Size(899, 150);
            dgProductos.TabIndex = 1;
            dgProductos.CellContentClick += dgProductos_CellContentClick;
            dgProductos.CellContentDoubleClick += dgProductos_CellContentDoubleClick;
            // 
            // txtProducto
            // 
            txtProducto.Location = new Point(6, 52);
            txtProducto.Name = "txtProducto";
            txtProducto.Size = new Size(177, 23);
            txtProducto.TabIndex = 2;
            // 
            // txtBuscar
            // 
            txtBuscar.Location = new Point(337, 271);
            txtBuscar.Name = "txtBuscar";
            txtBuscar.Size = new Size(102, 23);
            txtBuscar.TabIndex = 3;
            txtBuscar.Text = "Buscar";
            txtBuscar.UseVisualStyleBackColor = true;
            txtBuscar.Click += txtBuscar_Click;
            // 
            // gbFiltros
            // 
            gbFiltros.Controls.Add(rbCodigoBarras);
            gbFiltros.Controls.Add(rbCategoria);
            gbFiltros.Controls.Add(rbNombre);
            gbFiltros.Location = new Point(406, 13);
            gbFiltros.Name = "gbFiltros";
            gbFiltros.Size = new Size(200, 100);
            gbFiltros.TabIndex = 4;
            gbFiltros.TabStop = false;
            gbFiltros.Text = "Filtros";
            // 
            // rbCodigoBarras
            // 
            rbCodigoBarras.AutoSize = true;
            rbCodigoBarras.Location = new Point(49, 72);
            rbCodigoBarras.Name = "rbCodigoBarras";
            rbCodigoBarras.Size = new Size(151, 19);
            rbCodigoBarras.TabIndex = 2;
            rbCodigoBarras.Text = "Filtrar por código barras";
            rbCodigoBarras.UseVisualStyleBackColor = true;
            rbCodigoBarras.CheckedChanged += rbId_CheckedChanged;
            // 
            // rbCategoria
            // 
            rbCategoria.AutoSize = true;
            rbCategoria.Location = new Point(49, 49);
            rbCategoria.Name = "rbCategoria";
            rbCategoria.Size = new Size(128, 19);
            rbCategoria.TabIndex = 1;
            rbCategoria.Text = "Filtrar por categoria";
            rbCategoria.UseVisualStyleBackColor = true;
            rbCategoria.CheckedChanged += rbCategoria_CheckedChanged;
            // 
            // rbNombre
            // 
            rbNombre.AutoSize = true;
            rbNombre.Location = new Point(49, 22);
            rbNombre.Name = "rbNombre";
            rbNombre.Size = new Size(121, 19);
            rbNombre.TabIndex = 0;
            rbNombre.Text = "Filtrar por nombre";
            rbNombre.UseVisualStyleBackColor = true;
            rbNombre.CheckedChanged += rbNombre_CheckedChanged;
            // 
            // gbCategoria
            // 
            gbCategoria.Controls.Add(cbCategoria);
            gbCategoria.Controls.Add(label2);
            gbCategoria.Location = new Point(276, 131);
            gbCategoria.Name = "gbCategoria";
            gbCategoria.Size = new Size(200, 100);
            gbCategoria.TabIndex = 5;
            gbCategoria.TabStop = false;
            gbCategoria.Text = "Categoria";
            // 
            // cbCategoria
            // 
            cbCategoria.FormattingEnabled = true;
            cbCategoria.Location = new Point(24, 53);
            cbCategoria.Name = "cbCategoria";
            cbCategoria.Size = new Size(153, 23);
            cbCategoria.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(24, 24);
            label2.Name = "label2";
            label2.Size = new Size(58, 15);
            label2.TabIndex = 1;
            label2.Text = "Categoria";
            // 
            // gbCodigoBarras
            // 
            gbCodigoBarras.Controls.Add(txtCodigoBarras);
            gbCodigoBarras.Controls.Add(label3);
            gbCodigoBarras.Location = new Point(548, 131);
            gbCodigoBarras.Name = "gbCodigoBarras";
            gbCodigoBarras.Size = new Size(200, 100);
            gbCodigoBarras.TabIndex = 6;
            gbCodigoBarras.TabStop = false;
            gbCodigoBarras.Text = "Código de barras";
            // 
            // txtCodigoBarras
            // 
            txtCodigoBarras.Location = new Point(14, 53);
            txtCodigoBarras.Name = "txtCodigoBarras";
            txtCodigoBarras.Size = new Size(180, 23);
            txtCodigoBarras.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(17, 24);
            label3.Name = "label3";
            label3.Size = new Size(97, 15);
            label3.TabIndex = 1;
            label3.Text = "Código de barras";
            // 
            // gbNombre
            // 
            gbNombre.Controls.Add(label1);
            gbNombre.Controls.Add(txtProducto);
            gbNombre.Location = new Point(12, 131);
            gbNombre.Name = "gbNombre";
            gbNombre.Size = new Size(200, 100);
            gbNombre.TabIndex = 7;
            gbNombre.TabStop = false;
            gbNombre.Text = "Nombre";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 27);
            label4.Name = "label4";
            label4.Size = new Size(97, 15);
            label4.TabIndex = 9;
            label4.Text = "Código de barras";
            // 
            // txtId
            // 
            txtId.Location = new Point(140, 27);
            txtId.Name = "txtId";
            txtId.ReadOnly = true;
            txtId.Size = new Size(66, 23);
            txtId.TabIndex = 10;
            txtId.TextChanged += txtId_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 73);
            label5.Name = "label5";
            label5.Size = new Size(122, 15);
            label5.TabIndex = 11;
            label5.Text = "Nombre del producto";
            // 
            // txtNombreProducto
            // 
            txtNombreProducto.Location = new Point(140, 69);
            txtNombreProducto.Name = "txtNombreProducto";
            txtNombreProducto.ReadOnly = true;
            txtNombreProducto.Size = new Size(165, 23);
            txtNombreProducto.TabIndex = 12;
            // 
            // btAñadir
            // 
            btAñadir.Enabled = false;
            btAñadir.Location = new Point(493, 271);
            btAñadir.Name = "btAñadir";
            btAñadir.Size = new Size(113, 23);
            btAñadir.TabIndex = 8;
            btAñadir.Text = "Añadir producto";
            btAñadir.UseVisualStyleBackColor = true;
            btAñadir.Click += btAñadir_Click;
            // 
            // gbDatosProducto
            // 
            gbDatosProducto.Controls.Add(label4);
            gbDatosProducto.Controls.Add(txtNombreProducto);
            gbDatosProducto.Controls.Add(txtId);
            gbDatosProducto.Controls.Add(label5);
            gbDatosProducto.Location = new Point(18, 12);
            gbDatosProducto.Name = "gbDatosProducto";
            gbDatosProducto.Size = new Size(311, 100);
            gbDatosProducto.TabIndex = 13;
            gbDatosProducto.TabStop = false;
            gbDatosProducto.Text = "Datos Producto";
            // 
            // btRetornarProducto
            // 
            btRetornarProducto.Enabled = false;
            btRetornarProducto.Location = new Point(158, 271);
            btRetornarProducto.Name = "btRetornarProducto";
            btRetornarProducto.Size = new Size(126, 23);
            btRetornarProducto.TabIndex = 14;
            btRetornarProducto.Text = "Retornar Producto";
            btRetornarProducto.UseVisualStyleBackColor = true;
            btRetornarProducto.Visible = false;
            btRetornarProducto.Click += btRetornarProducto_Click;
            // 
            // ConsultarProducto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(899, 450);
            ControlBox = false;
            Controls.Add(btRetornarProducto);
            Controls.Add(gbDatosProducto);
            Controls.Add(btAñadir);
            Controls.Add(gbNombre);
            Controls.Add(gbCodigoBarras);
            Controls.Add(gbCategoria);
            Controls.Add(gbFiltros);
            Controls.Add(txtBuscar);
            Controls.Add(dgProductos);
            FormBorderStyle = FormBorderStyle.None;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "ConsultarProducto";
            StartPosition = FormStartPosition.CenterParent;
            Text = "ConsultarProducto";
            Load += ConsultarProducto_Load;
            ((System.ComponentModel.ISupportInitialize)dgProductos).EndInit();
            gbFiltros.ResumeLayout(false);
            gbFiltros.PerformLayout();
            gbCategoria.ResumeLayout(false);
            gbCategoria.PerformLayout();
            gbCodigoBarras.ResumeLayout(false);
            gbCodigoBarras.PerformLayout();
            gbNombre.ResumeLayout(false);
            gbNombre.PerformLayout();
            gbDatosProducto.ResumeLayout(false);
            gbDatosProducto.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
        private DataGridView dgProductos;
        private TextBox txtProducto;
        private Button txtBuscar;
        private GroupBox gbFiltros;
        private RadioButton rbCodigoBarras;
        private RadioButton rbCategoria;
        private RadioButton rbNombre;
        private GroupBox gbCategoria;
        private GroupBox gbCodigoBarras;
        private GroupBox gbNombre;
        private ComboBox cbCategoria;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Button btAñadir;
        private TextBox txtCodigoBarras;
        public TextBox txtId;
        public Button btRetornarProducto;
        public GroupBox gbDatosProducto;
        public TextBox txtNombreProducto;
    }
}