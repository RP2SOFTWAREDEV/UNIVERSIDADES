﻿namespace seminario2.Interfases.VentanaReportes
{
    partial class Reportes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btGastos = new Button();
            btGanancias = new Button();
            btUtilidades = new Button();
            dateTimePicker1 = new DateTimePicker();
            dateTimePicker2 = new DateTimePicker();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // btGastos
            // 
            btGastos.Location = new Point(170, 275);
            btGastos.Name = "btGastos";
            btGastos.Size = new Size(75, 23);
            btGastos.TabIndex = 0;
            btGastos.Text = "Gastos";
            btGastos.UseVisualStyleBackColor = true;
            // 
            // btGanancias
            // 
            btGanancias.Location = new Point(61, 275);
            btGanancias.Name = "btGanancias";
            btGanancias.Size = new Size(75, 23);
            btGanancias.TabIndex = 1;
            btGanancias.Text = "Ganancias";
            btGanancias.UseVisualStyleBackColor = true;
            // 
            // btUtilidades
            // 
            btUtilidades.Location = new Point(289, 275);
            btUtilidades.Name = "btUtilidades";
            btUtilidades.Size = new Size(75, 23);
            btUtilidades.TabIndex = 2;
            btUtilidades.Text = "Utilidades";
            btUtilidades.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(142, 27);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(209, 23);
            dateTimePicker1.TabIndex = 3;
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Location = new Point(140, 103);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(209, 23);
            dateTimePicker2.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(97, 33);
            label1.Name = "label1";
            label1.Size = new Size(39, 15);
            label1.TabIndex = 5;
            label1.Text = "Desde";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(97, 109);
            label2.Name = "label2";
            label2.Size = new Size(37, 15);
            label2.TabIndex = 6;
            label2.Text = "Hasta";
            // 
            // Reportes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(417, 303);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dateTimePicker2);
            Controls.Add(dateTimePicker1);
            Controls.Add(btUtilidades);
            Controls.Add(btGanancias);
            Controls.Add(btGastos);
            Name = "Reportes";
            Text = "Reportes";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btGastos;
        private Button btGanancias;
        private Button btUtilidades;
        private DateTimePicker dateTimePicker1;
        private DateTimePicker dateTimePicker2;
        private Label label1;
        private Label label2;
    }
}