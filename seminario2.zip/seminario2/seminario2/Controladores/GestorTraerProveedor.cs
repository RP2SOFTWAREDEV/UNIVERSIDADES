﻿using seminario2.Clases_de_Entidad;
using seminario2.Interfases.VentanaProveedores;
using seminario2.Interfases.VentanaProveedorXProducto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace seminario2.Controladores
{
    public class GestorTraerProveedor
    {
        
        string nombre_proveedor;
        string razon_social;
        string telefono;
        int id_proveedor;
        ConsultarProveedor consulta;
        AñadirProveedorxProducto item;
        Proveedor proveedor;

        public GestorTraerProveedor(ConsultarProveedor consulta, AñadirProveedorxProducto item, Proveedor proveedor)
        {
            this.consulta = consulta;
            this.item = item;
            this.proveedor = proveedor;
        }

        public GestorTraerProveedor()
        {
        }

        public GestorTraerProveedor(AñadirProveedorxProducto item)
        {
            this.item = item;
            consulta = new ConsultarProveedor();
            consulta.btRetornar.Visible = true;
        }
        public void LlenarControladores() 
        {
            consulta.ShowDialog();
// llenar controladores de añadir proveedor x producto
            nombre_proveedor = consulta.txtNombre.Text;
            razon_social = consulta.txtRazonSocial.Text;
            telefono = consulta.txtTelefono.Text;
            id_proveedor = Convert.ToInt32(consulta.txtIdProveedor.Text);
            item.txtIdProveedor.Text = id_proveedor.ToString();
            item.txtTelefono.Text = telefono.ToString();
            item.txtRazonSocial.Text = razon_social;
            item.txtProveedor.Text = nombre_proveedor;

        }
    }
}
