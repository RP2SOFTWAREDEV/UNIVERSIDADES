﻿using seminario2.Interfases.VentanaProducto;
using seminario2.Interfases.VentanaProveedorXProducto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace seminario2.Controladores
{
    internal class GestorTraerProducto
    {
        string codigo_barras;
        string nombre_producto;
        ConsultarProducto consulta;
        AñadirProveedorxProducto item;

        public GestorTraerProducto(ConsultarProducto consulta)
        {
            
            this.consulta = consulta;
            consulta.btRetornarProducto.Visible = true;
            consulta.gbDatosProducto.Visible = true;
        }

        public GestorTraerProducto(AñadirProveedorxProducto item): this(new ConsultarProducto())
        {
            this.item = item;
        }

        public GestorTraerProducto(): this(new ConsultarProducto())
        {
           
            
        }

        public void LlenarControladores()
        {
            consulta.ShowDialog();
            codigo_barras = consulta.txtId.Text;
            nombre_producto = consulta.txtNombreProducto.Text;
            item.txtCodigoBarras.Text = codigo_barras;
            item.txtProducto.Text = nombre_producto;
        }
    }
}
