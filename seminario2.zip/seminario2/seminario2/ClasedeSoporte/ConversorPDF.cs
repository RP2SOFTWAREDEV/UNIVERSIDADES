﻿using seminario2.Clases_de_Entidad;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Org.BouncyCastle.Crmf;
using System.Diagnostics;

namespace seminario2.ClasedeSoporte
{
    public class ConversorPDF
    {
        public static void Convertir (Factura factura)
        {
            //creando documento
            Document archivo = new Document(PageSize.A4, 25, 25, 25, 25);
            using (FileStream fs = new FileStream ("C:\\Users\\Fatima\\source\\repos\\seminario2\\seminario2\\Facturas\\Factura " + factura.Get_NroFactura() + ".pdf", FileMode.Create)) {
                PdfWriter writer = PdfWriter.GetInstance(archivo, fs);
                archivo.Open();

                

                //información de la factura
                AgregarEncabezado(factura, archivo);
                AgregarProductos(factura, archivo);
                AgregarFormadePago(factura, archivo);
                AgregarPiedePagina(factura, archivo);

                archivo.Close();
                MessageBox.Show("Ruta: " + fs.Name);
                AbrirPDF(fs.Name);
            }
        }
        static void AbrirPDF(string rutaFactura)
        {
            if (File.Exists(rutaFactura))
            {
                OpenFileDialog abrirArchivo = new OpenFileDialog();
                abrirArchivo.FileName = rutaFactura;
                abrirArchivo.OpenFile();
            }
            else
            {
                Console.WriteLine("Error: Archivo PDF no encontrado en la ruta: " + rutaFactura);
            }
        }
        private static void AgregarEncabezado (Factura factura, Document archivo)
        {
                        
            archivo.Add(new Paragraph("Nro de Factura: " + factura.Get_NroFactura()));
            archivo.Add(new Paragraph("Fecha: " + factura.Get_Fecha()));
            archivo.Add(new Paragraph("Nombre: " + factura.Get_NombreCliente()));

        }
        private static void AgregarProductos(Factura factura, Document archivo)
        {
            PdfPTable pdftabla = new PdfPTable(5);
            PdfPCell celda = new PdfPCell(new Phrase("id Detalle Factura"));
            pdftabla.AddCell(celda);
            celda = new PdfPCell(new Phrase("Producto"));
            pdftabla.AddCell(celda);
            celda = new PdfPCell(new Phrase("Precio Unitario"));
            pdftabla.AddCell(celda);
            celda = new PdfPCell(new Phrase("Cantidad"));
            pdftabla.AddCell(celda);
            celda = new PdfPCell(new Phrase("Subtotal"));
            pdftabla.AddCell(celda);
            Paragraph p1 = new Paragraph("Producto");
            archivo.Add(p1);

            foreach (DetalleFactura df in factura.Get_DetalleFactura())
            {
                string s = df.Get_IdDetalleFactura().ToString();
                celda = new PdfPCell(new Phrase(s));
                pdftabla.AddCell(celda);
                s = df.Get_Nombre().ToString();
                celda = new PdfPCell(new Phrase(s));
                pdftabla.AddCell(celda);
                s = df.Get_Precio().ToString();
                celda = new PdfPCell(new Phrase(s));
                pdftabla.AddCell(celda);
                s = df.Get_Cantidad().ToString();
                celda = new PdfPCell(new Phrase(s));
                pdftabla.AddCell(celda);
                s = df.subtotal().ToString();
                celda = new PdfPCell(new Phrase(s));
                pdftabla.AddCell(celda);

                         
               
                //  archivo.Add(detallefactura);
               
            }
            archivo.Add(pdftabla);
        }
        private static void AgregarFormadePago(Factura factura, Document archivo)
        {
            Paragraph p2 = new Paragraph("Formas de pago");
            archivo.Add(p2);
            foreach (ItemFormaPago itemFormaPago in factura.Get_itemformadepago())
            {
                string s = itemFormaPago.ToString();
                archivo.Add(new Paragraph(s));
            }

        }
        private static void AgregarPiedePagina(Factura factura, Document archivo)
        {

        }
    }
}
