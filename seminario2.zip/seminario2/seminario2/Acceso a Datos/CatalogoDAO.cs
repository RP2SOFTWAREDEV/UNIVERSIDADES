﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace seminario2.Acceso_a_Datos
{
    public class CatalogoDAO: DAO
    {
        static string tabla = "proveedor_x_producto";

        public static DataTable TraerTodos()
        {
            TraerBaseDatos(tabla);
            return bd.TraerTodos();
        }

        public static void InsertarUno(int id_proveedor, string codigo_barras, double precio)
        {
            TraerBaseDatos(tabla);
            string cadena = "insert into proveedor_x_producto (id_proveedor, codigo_barras, precio) values ("+id_proveedor+", '"+codigo_barras+"', "+precio+")";
            MessageBox.Show("Se ha insertado correctamente");
            bd.EjecutarComando(cadena);
        }

        public static DataTable TraerInfo()
        {
            TraerBaseDatos(tabla);
            string consulta = "select prod.codigo_barras, prod.nombre, prod.precio, prov.id_proveedor, prov.nombre, prov.razon_social, prov.telefono  \r\nfrom proveedor_x_producto c join proveedores prov on c.id_proveedor = prov.id_proveedor\r\njoin productos prod on c.codigo_barras = prod.codigo_barras";
            return bd.TraerTabla(consulta);
        }
    }
}
