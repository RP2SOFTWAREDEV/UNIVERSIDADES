﻿using seminario2.Clases_de_Entidad;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace seminario2.Acceso_a_Datos
{
    public class ProveedorDAO:DAO
    {
        static string tabla = "proveedores";

        public static DataTable TraerTodos()
        {
            bd = TraerBaseDatos(tabla);
            return bd.TraerTodos();
        }
        public static void InsertarUno(Proveedor p)
        {
            TraerBaseDatos(tabla);
            string consulta = "insert into proveedores (id_proveedor, nombre, email, telefono, direccion, razon_social, cuit) values ";
            consulta += string.Format("('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}');", p.Get_idProveedor(), p.Get_nombre(), p.Get_email(), p.Get_telefono(), p.Get_direccion(), p.Get_razonSocial(), p.Get_cuit());
            
            bd.EjecutarComando(consulta);
        }
        public static void ModificarUno(Proveedor p)
        {
            TraerBaseDatos(tabla);
            string consulta = string.Format("update proveedores set nombre = '{1}', email = '{2}', telefono = '{3}',direccion = '{4}', razon_social = '{5}', cuit = '{6}' where id_proveedor = {0}", p.Get_idProveedor(), p.Get_nombre(), p.Get_email(), p.Get_telefono(), p.Get_direccion(), p.Get_razonSocial(), p.Get_cuit());
           
            bd.EjecutarComando(consulta);
        }
        public static void EliminarUno (Proveedor p)
        {
            TraerBaseDatos(tabla);
            string consulta = "delete from proveedores where id_proveedor = '" + p.Get_idProveedor() + "'";
            bd.EjecutarComando(consulta);
        }
        public static void EliminarUno (int idProveedor)
        {
            TraerBaseDatos(tabla);
            string consulta = "delete from proveedores where id_proveedor = '"+ idProveedor +"'";
            bd.EjecutarComando(consulta);
        }
        public static int ObtenerProximoId()
        {
            TraerBaseDatos("proveedores");
            int id;
            string consulta = "select max(id_proveedor) from proveedores";
            DataTable tabla = bd.TraerTabla(consulta);
            if (tabla.Rows[0][0] is System.DBNull) id = 1;

            else id = (int)tabla.Rows[0][0] + 1;
            return id;
        }
        public static DataTable BuscarPorCampo(string campo, string valor)
        {
            bd = TraerBaseDatos("proveedores");
            //buscar al proveedor que se llame Juan
            string consulta = "select * from proveedores where "+campo+" like '%"+valor+"%'";
          
            DataTable table = bd.TraerTabla(consulta);
            return table;
        }
        public static Proveedor TraerUno(int IdProveedor)
        {
            Proveedor proveedor = new Proveedor();
            string consulta = "select * from proveedores where id_proveedor = "+IdProveedor+"";
            DataTable table = bd.TraerTabla(consulta);
            decimal cuit = Convert.ToDecimal(table.Rows[0]["cuit"].ToString());
            string razonSocial = table.Rows[0]["razon_socail"].ToString();
            string direccion = table.Rows[0]["direccion"].ToString();
            string telefono = table.Rows[0]["telefono"].ToString();
            string email = table.Rows[0]["email"].ToString();
            string nombre = table.Rows[0]["nombre"].ToString();
            int idProveedor = Convert.ToInt32(table.Rows[0]["id_proveedor"].ToString());

            proveedor.Set_cuit(cuit);
            proveedor.Set_razonSocial(razonSocial);
            proveedor.Set_direccion(direccion);
            proveedor.Set_telefono(telefono);
            proveedor.Set_email(email);
            proveedor.Set_nombre(nombre);
            proveedor.Set_idProveedor(idProveedor);
            return proveedor;

        }
    }
}
