﻿using seminario2.Clases_de_Entidad;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace seminario2.Acceso_a_Datos
{
    public class EstadisticasDAO:DAO
    {
        public static DataTable Obtener10ProductosMasVendidos(DateTime desde, DateTime hasta)
        {
            string consulta = "select p.nombre, sum(d_f.cantidad) as 'cantidad_total' " +
                "from factura f join detalle_factura d_f on (f.nro_factura = d_f.nro_factura) join productos p" +
                " on (p.codigo_barras = d_f.codigo_barras)" +
                "where f.fecha > str_to_date('" + desde.ToString("'yyyy'-'mm'-'dd'") + "', '%Y-%m-%d')"+
                "and f.fecha < str_to_date('" + hasta.ToString("'yyyy'-'mm'-'dd'") + "', '%Y-%m-%d')" +
                "group by p.codigo_barras order by sum(d_f.cantidad) desc limit 10";

            return bd.TraerTabla(consulta);
        }

        public static DataTable obtener5ProductosMenosVendidos(DateTime desde, DateTime hasta)
        {
            string consulta = "select p.nombre, sum(d_f.cantidad) as 'cantidad_total'" +
                "from factura f join detalle_factura d_f on (f.nro_factura = d_f.nro_factura) join productos p" +
                "on (p.codigo_barras = d_f.codigo_barras)" +
                "where f.fecha > str_to_date('" + desde.ToString("'yyyy'-'mm'-'dd'") + "', '%Y-%m-%d')" +
                "and f.fecha < str_to_date('" + hasta.ToString("'yyyy'-'mm'-'dd'") + "', '%Y-%m-%d')" +
                "group by p.codigo_barras" +
                "order by sum(d_f.cantidad) asc limit 5";

            return bd.TraerTabla(consulta);
        }

         public static DataTable obtenerVentadeProductoPorMes(string codigo_barras)
        {
          string consulta = "select p.nombre, concat(year(f.fecha), '-', month(f.fecha)) as fecha, sum(d_f.cantidad) as cantidad" +
                "from factura f join detalle_factura d_f on (f.nro_factura = d_f.nro_factura) join productos p " +
                "on (p.codigo_barras = d_f.codigo_barras) where p.codigo_barras = '"+codigo_barras+"'" +
                "and f.fecha > curdate() - interval 12 month and f.fecha < curdate() group by concat(year(f.fecha), '-', month(f.fecha))";

            return bd.TraerTabla(consulta);
        }   
    }
}
