﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace seminario2.Acceso_a_Datos
{
    public interface IDAO
    {
        public static Object TraerUno(int id)
        {
            return null;
        }

        public static void ModificarUno(Object O)
        {

        }

        public static void BorrarUno(int id)
        {

        }

        public static void InsertarUno(object o)
        {

        }
    }
}
