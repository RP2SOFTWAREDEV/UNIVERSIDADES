﻿using MySqlX.XDevAPI.Relational;
using seminario2.Clases_de_Entidad;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace seminario2.Acceso_a_Datos
{
  

    public class DetalleFacturaDAO:DAO

    {
        static string tabla = "detalle_factura";
        public static DataTable TraerTodos()
            
        {
            bd = new BasedeDatos(tabla);
            return bd.TraerTodos();
        }

        public static DataTable TraerInfo(int id)
        {

            string consulta = "select d.id_detalle_factura, p.nombre, d.precio, d.cantidad, d.cantidad* d.precio as 'subtotal' from detalle_factura d inner join productos p on d.codigo_barras = p.codigo_barras where nro_factura = '"+id+"'";
            return bd.TraerTabla(consulta);
            
        }

        public static int ObtenerProximoId(int id_factura)
        {
            int id = 1;
            string consulta = "select max(id_detalle_factura) from detalle_factura where nro_factura = '"+id_factura+"'";
            DataTable resultado = bd.TraerTabla(consulta);
             if (resultado != null)
            {
                try
                {
                    id = Convert.ToInt32(resultado.Rows[0][0]);
                    id++;
                }
                catch (Exception)
                {
                    MessageBox.Show("Error proximo id" + resultado.Rows[0][0]);
                    id = 1;
                }
            }
            return id;
        }
        public static void InsertarUno(DetalleFactura df)
        {
            string consulta = "insert into detalle_factura (nro_factura, id_detalle_factura, codigo_barras, precio,cantidad) values (";
            consulta += df.Get_NroFactura() + ", ";
            consulta += df.Get_IdDetalleFactura() + ", ";
            consulta += df.Get_IdProducto() + ", ";
            consulta += df.Get_Precio() + ", ";
            consulta += df.Get_Cantidad() +")";
            bd.EjecutarComando(consulta);
            MessageBox.Show(consulta);
        }
        public static DetalleFactura TraerUno(int idDetalleFactura, int idFactura)
        {
            DetalleFactura df = new DetalleFactura();
            string consulta = ("select * from detalle_factura where id_detalle_factura = '" + idDetalleFactura + "' and nro_factura = '" + idFactura + "'");
            DataTable tabla = bd.TraerTabla(consulta);
            string idProducto;
            int cantidad;
            double precio;
            Producto producto;

            idProducto = (string)tabla.Rows[0][0];
            cantidad = (int)tabla.Rows[0][1];
            precio = (double)tabla.Rows[0][2];
            producto = ProductoDAO.TraerUno(idProducto);

            df.Set_IdProducto(idProducto);
            df.Set_Cantidad(cantidad);
            df.Set_Precio(precio);
            df.Set_Producto(producto);
            return df;
        }

        public static List<DetalleFactura> TraerTodosdeFactura(int nroFactura)
        {
            List<DetalleFactura> detallesFactura = new List<DetalleFactura>();
            string consulta = "select * from detalle_factura where nro_factura = '" + nroFactura + "'";
            DataTable tabla = bd.TraerTabla(consulta);
            for (int i = 0; i < tabla.Rows.Count; i++)
            {
                DetalleFactura df = new DetalleFactura();
                string idProducto;
                int cantidad;
                double precio;
                Producto producto;
                
                idProducto = Convert.ToString(tabla.Rows[i][2]);
                cantidad = (int)tabla.Rows[i][4];
                precio = (double)tabla.Rows[i][3];
                producto = ProductoDAO.TraerUno(Convert.ToString(idProducto));
                df.Set_IdDetalleFactura(i+1);
                df.Set_IdProducto(Convert.ToString(idProducto));
                df.Set_Cantidad(cantidad);
                df.Set_Precio(precio);
                df.Set_Producto(producto);
                detallesFactura.Add(df);
            }
           
            return detallesFactura;
        }
    }
}
