﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace seminario2.Acceso_a_Datos
{
    internal class UsuarioDAO:DAO
    {
        static string tabla = "usuarios";
        
        public static bool esUsuarioValido(string nombre, string contraseña)
        {
            
            TraerBaseDatos(tabla);
            string consulta = "select count(*) as cantidad from usuarios where nombre='"+nombre+"' and contraseña='"+contraseña+"'";
            DataTable resultado = bd.TraerTabla(consulta);
            if (Convert.ToInt32(resultado.Rows[0]["cantidad"]) == 1)
            {
                return true;
            }
                return false;
        }

        internal static int obtenerId(string nombre)
        {
            TraerBaseDatos(tabla);
            string consulta = " select id_usuario from usuarios where nombre = ' " + nombre + "'";
            DataTable resultado = bd.TraerTabla(consulta);
            int id = (int)resultado.Rows[0]["id_usuario"];
            return id;
        }
    }
}
