﻿using seminario2.Clases_de_Entidad;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace seminario2.Acceso_a_Datos
{
    public
        class ListaFormaPagoDAO : DAO
    {
        public static string tabla = "lista_forma_pago";

        public static void InsertarUno (Factura f, ItemFormaPago item)
        {
            string consulta = "insert into lista_forma_pago (nro_factura, id_forma_pago, monto) values (";
            consulta += f.Get_NroFactura() + ", ";
            consulta += item.Get_fp().Get_IdFormaPago() + ", ";
            consulta += item.Get_monto() + ")";

            bd.EjecutarComando(consulta);
        }

        public static DataTable TraerTodos()
        {
            bd = new BasedeDatos(tabla);
            return bd.TraerTodos();
        }

        public static List<ItemFormaPago> TraerTodosdeFactura(int nro_factura)
        {
            List < ItemFormaPago > itemsFormaPago = new List<ItemFormaPago>();
            string consulta = "select *from lista_forma_pago where nro_factura = '" + nro_factura + "'";
            DataTable tabla = bd.TraerTabla(consulta);
            for (int i = 0; i < tabla.Rows.Count; i++)
            {
                ItemFormaPago itemFormaPago = new ItemFormaPago();
                FormadePago formaPago;
                double monto;

                formaPago = FormadePagoDAO.TraerUno((int)tabla.Rows[i][1]);
                monto = (double)tabla.Rows[i][2];

                itemFormaPago.Set_fp(formaPago);  
                itemFormaPago.Set_monto(monto);
                itemsFormaPago.Add(itemFormaPago);

            }
                return itemsFormaPago;
        }

        
    }
}
