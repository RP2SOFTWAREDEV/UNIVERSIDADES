﻿using seminario2.Clases_de_Entidad;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace seminario2.Acceso_a_Datos
{
    public class FormadePagoDAO : DAO
    {
        static string tabla = "formas_pago";

        public static DataTable TraerTodos()
        {
            TraerBaseDatos(tabla);
            SetTabla(tabla);          
            return bd.TraerTodos();
        }
        public static void InsertarUno()
        {

        }
        public static FormadePago TraerUno(int id)
        {
            FormadePago formadepago = new FormadePago();
            string consulta = "select * from formas_pago where id_forma_pago = " + id;
            DataTable table = bd.TraerTabla(consulta);

            if (table.Rows.Count < 1)
            {
                MessageBox.Show("No se encontró ninguna forma de pago con el ID: " + id);
                return formadepago;
            }

            int id_forma_pago = (int)table.Rows[0]["id_forma_pago"];
            string? nombre = table.Rows[0]["nombre"].ToString();
            formadepago = new FormadePago(id_forma_pago, nombre == null ? "Error" : nombre);
            return formadepago;
        }
        public static FormadePago TraerUno(string nombre)
        {
            FormadePago formadepago = new FormadePago();
            string consulta = "select * from formas_pago where nombre = '" + nombre +"'";
            DataTable table = bd.TraerTabla(consulta);

            if (table.Rows.Count < 1)
            {
                MessageBox.Show("No se encontró ninguna forma de pago con el Nombre: " + nombre);
                return formadepago;
            }

            int id_forma_pago = (int)table.Rows[0]["id_forma_pago"];
            string? name = table.Rows[0]["nombre"].ToString();
            formadepago = new FormadePago(id_forma_pago, name == null ? "No se encuentra" :name);
            return formadepago;
        }

        public static FormadePago TraerEfectivo()
        {
            return TraerUno("efectivo");
        }
        public static FormadePago TraerDebito()
        {
            return TraerUno("debito");
        }
        public static FormadePago TraerFiado()
        {
            return TraerUno("fiado");
        }
        public static FormadePago TraerCredito()
        {
            return TraerUno("credito");
        }
    }

}
