﻿using seminario2.Acceso_a_Datos;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace seminario2.Clases_de_Entidad
{
    public class Factura
    {
        private int nro_factura, dni;
        private DateTime fecha;
        private string nombre_cliente, domicilio, mail, telefono;
        private List<DetalleFactura> items;
        private List<ItemFormaPago> item_formadepago;

        public Factura(int nro_factura, int dni, DateTime fecha, string nombre_cliente, string domicilio, string mail, string telefono, List<DetalleFactura> items, List<ItemFormaPago> item_formadepago)
        {
            this.nro_factura = nro_factura;
            this.dni = dni;
            this.fecha = fecha;
            this.nombre_cliente = nombre_cliente;
            this.domicilio = domicilio;
            this.mail = mail;
            this.telefono = telefono;
            this.items = items;
            this.item_formadepago = item_formadepago;
        }

        public Factura(int nro_factura, DateTime fecha, string nombre_cliente)
        {
            this.nro_factura = nro_factura;
            this.fecha = fecha;
            this.nombre_cliente = nombre_cliente;
            items = new List<DetalleFactura>();
            item_formadepago = new List<ItemFormaPago>();
        }

        public Factura()
        {
            items = new List<DetalleFactura>();
            item_formadepago = new List<ItemFormaPago>();
        }

        public int Get_NroFactura()
        {
            return nro_factura;
        }

        public DateTime Get_Fecha()
        {
            return fecha;
        }

        public string Get_NombreCliente()
        {
            return nombre_cliente;
        }

        public List<ItemFormaPago> Get_itemformadepago()
        {
            return item_formadepago;
        }
        public void Set_detallesFactura (List<DetalleFactura> detallesFacturas)
        {
            this.items = detallesFacturas;
        }
        public void Set_itemformadepago(List<ItemFormaPago> item_formadepago)
        {
            this.item_formadepago = item_formadepago;
        }
        public void Set_NroFactura(int nro_factura)
        {
            this.nro_factura = nro_factura;
        }

        public void Set_Fecha(DateTime fecha)
        {
            this.fecha = fecha;
        }

        public void Set_NombreCliente(string nombre_cliente)
        {
            this.nombre_cliente = nombre_cliente;
        }

        public void Set_Domicilio(string domicilio)
        {
            this.domicilio = domicilio;
        }

        public void Set_Mail(string mail)
        {
            this.mail = mail;
        }

        public void Set_Dni(int dni)
        {
            this.dni = dni;
        }

        public void Set_Telefono(string telefono)
        {
            this.telefono = telefono;
        }

        private DateTime hoy()
        {
            DateTime hoy = DateTime.Now;
            return hoy;
        }

        public DetalleFactura crearDetalleFactura(Producto p, int cantidad)
        {
            if (!p.puedoVender(cantidad))
            {
                throw new Exception("No hay suficiente stock");
            }
            int nro_factura = this.nro_factura;
            string nombre = p.GetNombre();
            string codigo_barras = p.GetIdProducto();
            double precio = p.GetPrecio();
            int id_detalle_factura = this.items.Count + 1;
            DetalleFactura df = new DetalleFactura(nro_factura, nombre, id_detalle_factura, codigo_barras, precio, cantidad);
            return df;
         }

        public Boolean Add(DetalleFactura df)
        {
            items.Add(df);
            return true;
        }

        public Boolean Add(Producto p, int cantidad)
        {
            try
            {
                DetalleFactura df = this.crearDetalleFactura(p, cantidad);
                return this.Add(df);
            }
            catch (Exception x)
            {
                MessageBox.Show(x.ToString());
                return false;
            }            
        }

        public Double calcularTotal()
        {
            double total = 0;
            foreach (DetalleFactura df in items)
            {
                total = total + df.subtotal();
            }
            return total;
        }

        internal IEnumerable<DetalleFactura> Get_DetalleFactura()
        {
            return items;
        }
        public void AñadirItemdePago(ItemFormaPago item)
        {
            if (item.Get_monto() <= 0)
            {
                MessageBox.Show("El monto ingresado debe ser mayor a 0");
                return;
            }
            if (item.Get_monto() + TotalPagado() > calcularTotal())
            {
                MessageBox.Show("Monto excedido");
                return;
            }
            item_formadepago.Add(item);
        }
        public void AñadirItemdePago(FormadePago f, double monto)
        {
            ItemFormaPago item = new ItemFormaPago(f, monto);
            AñadirItemdePago(item);
        }
        public void AñadirPagoEfectivo(double monto)
        {
            FormadePago fp = FormadePagoDAO.TraerEfectivo();
            AñadirItemdePago(fp,monto);
        }
        public void AñadirPagoDebito(double monto)
        {
            FormadePago fp = FormadePagoDAO.TraerDebito();
            AñadirItemdePago(fp, monto);
        }
        public void AñadirPagoFiado(double monto)
        {
            FormadePago fp = FormadePagoDAO.TraerFiado();
            AñadirItemdePago(fp, monto);
        }
        public void AñadirPagoCredito(double monto)
        {
            FormadePago fp = FormadePagoDAO.TraerCredito();
            AñadirItemdePago(fp, monto);
        }
        public double TotalPagado()
        {
            //recorrer con un ciclo cada item de pago para sumar sus montos
            //retornar esa suma
            double total = 0;
            foreach (ItemFormaPago item_FormaPago in item_formadepago)
            {
                total += item_FormaPago.Get_monto();
            }
            return total;

        }
        public string MostrarItemsPago()
        {
            double total = calcularTotal();
            string cadena = "Total a pagar: $" + total;
            foreach (ItemFormaPago itemFormaPago in item_formadepago )
            {
                cadena += "\n\t" + itemFormaPago;
            }
            return cadena;
        }

        public override string ToString()
        {
            
                StringBuilder sb = new StringBuilder("Items: ");
                foreach (DetalleFactura df in this.items)
                {
                    sb.Append("\n\t" + df.ToString());
                }
                sb.Append(MostrarItemsPago() + "\n\t");
                return sb.ToString();
        }
    }



}
