﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace seminario2.Clases_de_Entidad
{
    public class Proveedor
    {
        int idProveedor;
        string nombre;
        string email;
        string telefono;
        string direccion;
        string razonSocial;
        decimal cuit;

        public Proveedor(int idProveedor, string nombre, string email, string telefono, string direccion, string razonSocial, decimal cuit)
        {
            this.idProveedor = idProveedor;
            this.nombre = nombre;
            this.email = email;
            this.telefono = telefono;
            this.direccion = direccion;
            this.razonSocial = razonSocial;
            this.cuit = cuit;
        }

        public Proveedor()
        {
        }

        public int Get_idProveedor()
        {
            return idProveedor;
        }
        public string Get_nombre()
        {
            return nombre;
        }
        public string Get_email()
        {
            return email;
        }
        public string Get_telefono()
        {
            return telefono;
        }
        public string Get_direccion()
        {
            return direccion;
        }
        public string Get_razonSocial()
        {
            return razonSocial;
        }
        public decimal Get_cuit()
        {
            return cuit;
        }
        public void Set_idProveedor(int idProveedor)
        {
            this.idProveedor = idProveedor;
        }
        public void Set_nombre(string nombre)
        {
            this.nombre = nombre;
        }
        public void Set_email(string email)
        {
            this.email = email;
        }
        public void Set_telefono(string telefono)
        {
            this.telefono = telefono;
        }
        public void Set_direccion(string direccion)
        {
            this.direccion =direccion;
        }
        public void Set_razonSocial(string razonSocial)
        {
            this.razonSocial = razonSocial;
        }
        public void Set_cuit(decimal cuit)
        {
            this.cuit = cuit;
        }
    }

}
