﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace seminario2.Clases_de_Entidad
{
    public class FormadePago
    {
        int id_forma_pago;
        string forma_pago;

        public FormadePago(int id_forma_pago, string forma_pago)
        {
            this.id_forma_pago = id_forma_pago;
            this.forma_pago = forma_pago;
        }

        public FormadePago()
        {
        }

        public int Get_IdFormaPago()
        {
            return id_forma_pago;
        }
        public string Get_FormaPago()
        {
            return forma_pago;
        }
        public void Set_IdFormaPago(int id_forma_pago)
        {
            this.id_forma_pago = id_forma_pago;
        }
        public void Set_FormaPago(string forma_pago)
        {
            this.forma_pago = forma_pago;
        }

    }
}
