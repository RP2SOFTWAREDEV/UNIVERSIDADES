﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace seminario2.Clases_de_Entidad
{
    public class ItemFormaPago
    {
        double monto;
        FormadePago fp;

        public ItemFormaPago(FormadePago fp)
        {
            this.fp = fp;
        }

        public ItemFormaPago(FormadePago fp, double monto)
        {
            this.monto = monto;
            this.fp = fp;
        }

        public ItemFormaPago()
        {
        }

        public double Get_monto()
        {
            return monto;
        }
        public FormadePago Get_fp()
        {
            return fp;
        }
        public void Set_monto(double monto)
        {
            this.monto = monto;
        }
        public void Set_fp(FormadePago fp)
        {
            this.fp = fp;
        }
        public override string ToString()
        {
            return fp.Get_FormaPago() + ": $" + monto;
        }
    }
}
